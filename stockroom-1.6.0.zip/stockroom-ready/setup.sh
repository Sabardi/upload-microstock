#!/usr/bin/env bash
# One-command installer/updater for Stockroom on Ubuntu/Debian VPS.
set -Eeuo pipefail

APP="stockroom"
INSTALL_DIR="/opt/stockroom"
SERVICE_FILE="/etc/systemd/system/stockroom.service"
PORT="${STOCKROOM_PORT:-8765}"
ROOT_HOME="$(getent passwd root | cut -d: -f6)"
DATA_ROOT="${STOCKROOM_ROOT:-$ROOT_HOME/Microstock}"
PYTHON="$(command -v python3 || true)"
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

fail() { echo "ERROR: $*" >&2; exit 1; }
[[ "$(id -u)" -eq 0 ]] || fail "Jalankan sebagai root: sudo bash setup.sh"
[[ -n "$PYTHON" ]] || fail "Python 3 belum tersedia. Install: apt-get install -y python3"
[[ -f "$HERE/app.py" ]] || fail "app.py tidak ditemukan. Ekstrak ZIP lalu jalankan setup.sh dari folder project."
[[ -f "$HERE/static/index.html" ]] || fail "static/index.html tidak ditemukan."
[[ "$PORT" =~ ^[0-9]+$ ]] && (( PORT >= 1024 && PORT <= 65535 )) || fail "Port tidak valid: $PORT"

echo "==> Memeriksa Python..."
"$PYTHON" - <<'PY'
import sys
if sys.version_info < (3, 8):
    raise SystemExit("Stockroom membutuhkan Python 3.8 atau lebih baru.")
print("Python", sys.version.split()[0])
PY

echo "==> Menghentikan service lama (jika ada)..."
systemctl stop "$APP" 2>/dev/null || true

echo "==> Memeriksa dukungan SFTP (opsional)..."
if command -v apt-get >/dev/null 2>&1; then
  if ! "$PYTHON" -c 'import paramiko' >/dev/null 2>&1; then
    apt-get install -y python3-paramiko >/dev/null 2>&1 || echo "INFO: Paramiko tidak terpasang; FTP/FTPS tetap tersedia. SFTP bisa diaktifkan nanti dengan: apt-get install -y python3-paramiko"
  fi
fi

echo "==> Memasang aplikasi ke $INSTALL_DIR..."
install -d -m 0755 "$INSTALL_DIR/static" "$DATA_ROOT"
install -d -m 0755 "$ROOT_HOME/.local/share/stockroom" "$ROOT_HOME/.cache/stockroom/thumbs"
install -m 0644 "$HERE/app.py" "$INSTALL_DIR/app.py"
install -m 0644 "$HERE/static/index.html" "$INSTALL_DIR/static/index.html"
chown -R root:root "$INSTALL_DIR"
chmod 0755 "$INSTALL_DIR" "$INSTALL_DIR/static"

echo "==> Membuat service systemd..."
cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Stockroom Microstock File Manager
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
Group=root
WorkingDirectory=$INSTALL_DIR
Environment=HOME=$ROOT_HOME
Environment=PYTHONUNBUFFERED=1
ExecStart=$PYTHON $INSTALL_DIR/app.py --root $DATA_ROOT --host 127.0.0.1 --port $PORT
Restart=on-failure
RestartSec=3
TimeoutStopSec=20
UMask=0022
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ReadWritePaths=$DATA_ROOT $ROOT_HOME/.local/share/stockroom $ROOT_HOME/.cache/stockroom

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$APP" >/dev/null
systemctl restart "$APP"

echo "==> Menunggu Stockroom aktif..."
for i in $(seq 1 20); do
  if "$PYTHON" - "$PORT" <<'PY' >/dev/null 2>&1
import sys, urllib.request
port = int(sys.argv[1])
with urllib.request.urlopen("http://127.0.0.1:%d/" % port, timeout=1) as r:
    raise SystemExit(0 if r.status == 200 else 1)
PY
  then
    break
  fi
  sleep 1
done

if ! "$PYTHON" - "$PORT" <<'PY'
import sys, urllib.request
port = int(sys.argv[1])
try:
    with urllib.request.urlopen("http://127.0.0.1:%d/" % port, timeout=2) as r:
        if r.status != 200: raise RuntimeError("HTTP %s" % r.status)
except Exception as e:
    print("Stockroom belum merespons:", e)
    raise SystemExit(1)
PY
then
  echo
  systemctl status "$APP" --no-pager || true
  journalctl -u "$APP" -n 50 --no-pager || true
  fail "Service gagal aktif. Periksa log di atas."
fi

echo
echo "=============================================="
echo " STOCKROOM BERHASIL DIPASANG / DIPERBARUI"
echo "=============================================="
echo "Versi       : 1.6.0"
echo "Folder data : $DATA_ROOT"
echo "Port lokal  : $PORT"
echo "Service     : systemctl status stockroom"
echo "Log         : journalctl -u stockroom -f"
echo
echo "Di laptop/Mac, jalankan:"
echo "ssh -N -L $PORT:127.0.0.1:$PORT root@IP_VPS_ANDA"
echo
echo "Lalu buka browser:"
echo "http://127.0.0.1:$PORT"
echo
echo "Keamanan: server hanya bind ke 127.0.0.1; jangan buka port $PORT ke internet."
echo "Database tanda upload lama tetap disimpan di $ROOT_HOME/.local/share/stockroom."
