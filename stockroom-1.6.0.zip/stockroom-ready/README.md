# Stockroom 1.6.0

Manajer file microstock untuk VPS Ubuntu/Debian. Mendukung dua panel file manager, pratinjau, penandaan marketplace, pemindahan/penyalinan, penghapusan terkontrol, upload file dari laptop ke VPS, serta FTP Manager (browser folder remote, antrean paralel dengan progres, resume, dan retry otomatis) untuk mengirim file ke platform microstock melalui FTP/FTPS/SFTP.

## Instalasi satu kali / update

Ekstrak ZIP, masuk ke folder `stockroom-ready`, lalu jalankan:

```bash
sudo bash setup.sh
```

Jika sudah login sebagai `root`, cukup:

```bash
bash setup.sh
```

Script akan:
- memasang aplikasi ke `/opt/stockroom`;
- membuat folder data `/root/Microstock` jika belum ada;
- membuat dan mengaktifkan systemd service `stockroom`;
- menguji HTTP lokal sebelum menyatakan instalasi berhasil;
- mempertahankan database tanda upload di `/root/.local/share/stockroom`.

Tidak perlu menginstall pip package. Python 3.8+ sudah cukup. Pillow dan FFmpeg hanya opsional untuk thumbnail dan metadata media.

## Mengakses dari Mac/laptop melalui SSH Tunnel

Di terminal laptop, biarkan perintah ini tetap berjalan:

```bash
ssh -N -L 8765:127.0.0.1:8765 root@IP_VPS_ANDA
```

Ganti `IP_VPS_ANDA` dengan IP VPS. Kemudian buka:

```text
http://127.0.0.1:8765
```

Jangan tutup terminal SSH selama aplikasi digunakan. Server sengaja hanya mendengarkan `127.0.0.1`, sehingga port aplikasi tidak terekspos langsung ke internet.

## Mengelola akun FTP/FTPS/SFTP

Di menu Kirim file ke platform, setiap profil akun memiliki tombol **Edit**, **Test**, dan **Hapus**. Saat mengedit, isi password boleh dikosongkan untuk mempertahankan password yang tersimpan; isi password baru hanya jika ingin menggantinya. Perubahan host, port, protokol, username, folder tujuan, dan nama akun disimpan pada profil yang sama sehingga tidak perlu membuat profil ulang.

## Mengelola service di VPS

```bash
systemctl status stockroom --no-pager
systemctl restart stockroom
systemctl stop stockroom
systemctl start stockroom
journalctl -u stockroom -f
```

## Mengubah port atau folder data

Default: port `8765`, folder `/root/Microstock`.

```bash
STOCKROOM_PORT=9000 bash setup.sh
```

Atau:

```bash
STOCKROOM_ROOT=/data/microstock bash setup.sh
```

Jalankan sebagai root. Setelah mengubah port, gunakan port yang sama pada SSH tunnel.

## Upload

Klik **Upload file** pada toolbar. Pilih satu atau beberapa file dari komputer. Upload berjalan satu per satu dan menampilkan progres tiap file. Jika nama file sudah ada, Stockroom menambahkan akhiran `(1)`, `(2)`, dan seterusnya; file lama tidak ditimpa. Batas saat ini 100 GB per file.


## FTP Manager (kirim ke platform microstock, ala FileZilla)

Klik **FTP Manager** di toolbar. Layarnya terbagi tiga:

- **Lokal** (kiri): folder di Stockroom. File yang kamu pilih di panel utama otomatis terpilih di sini.
- **Remote** (kanan): isi folder di server platform. Bisa buka folder, naik, buat folder, ganti nama, dan hapus di server.
- **Antrean transfer** (bawah): progres per file, kecepatan, sisa waktu, tab Antrean / Gagal / Berhasil / Log.

Cara kirim: pilih situs di bagian atas (otomatis terhubung), pilih file atau folder di panel Lokal, lalu klik **Upload ke situs** atau seret ke panel Remote. Menyeret ke sebuah folder remote mengirim ke folder itu. Folder lokal dikirim lengkap dengan isinya, subfolder dibuat otomatis di server.

**Situs (akun).** Klik **Kelola situs** untuk menambah, mengedit (Edit), menguji (Test), atau menghapus akun. Kolom password boleh kosong saat edit untuk mempertahankan password tersimpan. Tiap akun adalah situs tersendiri, misalnya `Shutterstock - Akun 1` dan `Shutterstock - Akun 2`, dan status terkirim dicatat per akun.

**Antrean.**
- *Paralel*: 1 sampai 5 koneksi sekaligus. Koneksi dipakai ulang antar file, jadi tidak login ulang untuk tiap file.
- *Bila sudah ada di server*: **Lanjutkan / lewati bila sama** (bawaan), Timpa, Lewati, atau Ganti nama. Pada mode bawaan, file yang sebagian sudah terkirim dilanjutkan dari titik terakhir, dan file yang ukurannya sama dianggap sudah lengkap.
- *Jeda antrean* menahan file berikutnya (yang sedang berjalan diselesaikan). Tombol **x** membatalkan satu file dan langsung memutus transfernya. **Ulangi** pada tab Gagal melanjutkan dari bagian yang sudah terkirim.
- Koneksi putus atau time-out diulang otomatis sampai 3 kali dengan melanjutkan dari bagian yang sudah terkirim. Kesalahan tetap (password salah, izin ditolak, kuota penuh) langsung ditandai gagal beserta pesannya.
- Setelah selesai, ukuran file di server dicocokkan dengan ukuran lokal. Kalau beda, dicoba ulang.
- Antrean disimpan di memori. Kalau service di-restart, antrean yang belum selesai hilang (file yang sudah terkirim tetap tercatat).

**Di panel Lokal**, file yang sudah terkirim ke situs terpilih diberi tanda *terkirim*. Centang **Sembunyikan yang terkirim** untuk fokus ke yang belum.

Profil bawaan:
- **Shutterstock**: FTPS explicit TLS, `ftps.shutterstock.com`, port `21`; isi email/username dan password Contributor. Panduan resmi: https://submit.shutterstock.com/help/en/articles/10617392-how-do-i-upload-content-via-ftps
- **Adobe Stock**: SFTP, port `22`; host, ID, dan password diambil dari menu Upload → Learn More di Contributor Portal (SFTP hanya untuk akun yang memenuhi syarat). Panduan resmi: https://helpx.adobe.com/stock/contributor/submit-your-content/submit-vectors/submit-vectors-to-adobe-stock.html
- **Custom**: FTP, FTPS, atau SFTP untuk server lain.

Untuk SFTP dibutuhkan Paramiko. `setup.sh` mencoba memasang `python3-paramiko`; kalau belum ada: `apt-get install -y python3-paramiko`.

**Kunci host SFTP.** Saat pertama kali tersambung ke server SFTP, sidik jari kuncinya disimpan (dipercaya pada pemakaian pertama). Kalau suatu hari kuncinya berubah, koneksi ditolak dengan pesan yang jelas, karena itu bisa berarti server diganti atau ada penyadapan. Kalau perubahannya wajar: Kelola situs, Edit, centang **Percayai ulang kunci host**, lalu simpan.

**Sertifikat FTPS.** Sertifikat server diverifikasi secara bawaan. Untuk server dengan sertifikat self-signed, matikan **Verifikasi sertifikat TLS** pada situs itu saja. Kanal data FTPS memakai ulang sesi TLS kanal kontrol, yang diwajibkan sebagian server.

**Keamanan:** kredensial situs disimpan di database lokal Stockroom pada server. File database dibatasi ke owner-only, tetapi password belum dienkripsi. Jangan membuka Stockroom ke internet publik; gunakan SSH tunnel dan lindungi akses server. Transfer FTPS dan SFTP terenkripsi; FTP biasa tidak.

**Penting:** transfer yang sukses hanya berarti file sudah sampai ke server platform. Ini tidak mengisi judul, keyword, kategori, release, atau mengirim aset untuk moderasi. Itu tetap dilakukan di Contributor Portal sesuai aturan platform masing-masing.

### Riwayat status multi-akun

Status keberhasilan FTP/SFTP disimpan terpisah dari tanda marketplace manual. Pada pratinjau file, bagian **Status per akun FTP/SFTP** menunjukkan akun mana yang sudah menerima file. Kalau situs dihapus, riwayatnya tetap ada di database, tetapi namanya tidak lagi ditampilkan.

## Catatan update

Jalankan kembali `bash setup.sh` dari folder versi baru. Script menghentikan service, mengganti kode aplikasi, lalu mengaktifkannya kembali. Folder data dan database status upload tidak dihapus.

## Troubleshooting

```bash
systemctl status stockroom --no-pager
journalctl -u stockroom -n 100 --no-pager
ss -lntp | grep 8765
```

Jika port sudah digunakan proses lain, pilih port berbeda menggunakan `STOCKROOM_PORT`.

## Pemeriksaan cepat

```bash
bash check.sh
```


## Download file ke komputer

Pilih satu atau beberapa file pada panel, lalu klik **Download**. Setiap file diunduh sebagai file terpisah (tidak dibuat ZIP). Lokasi penyimpanan mengikuti pengaturan browser: biasanya folder Downloads, atau dialog Save As jika browser diatur untuk selalu menanyakan lokasi penyimpanan. Untuk Safari, atur lokasi unduhan melalui Safari > Settings > General > File download location. Untuk Chrome, aktifkan Settings > Downloads > Ask where to save each file before downloading. Folder yang dipilih langsung tidak dikompres; buka folder tersebut dan pilih file di dalamnya.


## Stockroom 1.5.2 — Drag & Drop Upload

Seret file dari Finder/Desktop langsung ke area aplikasi Stockroom. File akan diunggah ke folder yang sedang aktif menggunakan antrean paralel (maksimal 3 file bersamaan). Tombol Upload File tetap tersedia.

## Akses langsung dari internet (tanpa SSH Tunnel)

Untuk akses aman tanpa Terminal lokal, gunakan domain milik sendiri yang DNS A record-nya mengarah ke IP VPS, lalu pasang reverse proxy HTTPS (misalnya Caddy) di depan Stockroom. Jangan expose port 8765 langsung ke internet. Akses publik wajib dilindungi autentikasi dan HTTPS. Konfigurasi domain belum otomatis dipasang oleh setup.sh; siapkan domain/subdomain dan pastikan port TCP 80 dan 443 dapat diakses dari internet.
