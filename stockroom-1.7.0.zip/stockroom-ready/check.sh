#!/usr/bin/env bash
set -euo pipefail
PORT="${STOCKROOM_PORT:-8765}"
echo "== Stockroom service =="
systemctl status stockroom --no-pager || true
echo
echo "== Listening port =="
ss -lntp | grep ":$PORT" || true
echo
echo "== HTTP/HTTPS check =="
python3 - "$PORT" <<'PY'
import ssl, sys, urllib.request
port = int(sys.argv[1])
for scheme in ("https", "http"):
    try:
        ctx = ssl._create_unverified_context() if scheme == "https" else None
        r = urllib.request.urlopen("%s://127.0.0.1:%d/" % (scheme, port), timeout=3, context=ctx)
        print("OK: %s %s (halaman login atau aplikasi terbuka)" % (scheme.upper(), r.status))
        raise SystemExit(0)
    except SystemExit:
        raise
    except Exception as e:
        last = e
print("FAILED:", last)
raise SystemExit(1)
PY
