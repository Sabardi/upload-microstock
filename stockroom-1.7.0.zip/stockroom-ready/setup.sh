#!/usr/bin/env bash
# Installer/updater Stockroom untuk VPS Ubuntu/Debian.
#
# Bawaan: akses langsung lewat browser di https://IP-VPS:PORT dengan login password.
#   sudo bash setup.sh                  pasang/perbarui (menanyakan password saat pertama kali)
#   sudo bash setup.sh --reset-password ganti password login
#   sudo bash setup.sh --local          hanya 127.0.0.1 (akses lewat SSH tunnel, tanpa login)
# Variabel opsional: STOCKROOM_PORT, STOCKROOM_ROOT, STOCKROOM_PASSWORD, STOCKROOM_TLS=0,
#                    STOCKROOM_ALLOW_FROM=IP_ANDA (buka port di firewall hanya untuk IP itu)
set -Eeuo pipefail

APP="stockroom"
INSTALL_DIR="${STOCKROOM_INSTALL_DIR:-/opt/stockroom}"
SERVICE_FILE="${STOCKROOM_SERVICE_FILE:-/etc/systemd/system/stockroom.service}"
TLS_DIR="${STOCKROOM_TLS_DIR:-/etc/stockroom/tls}"
PORT="${STOCKROOM_PORT:-8765}"
ROOT_HOME="${STOCKROOM_HOME:-$(getent passwd root | cut -d: -f6)}"
DATA_ROOT="${STOCKROOM_ROOT:-$ROOT_HOME/Microstock}"
PYTHON="$(command -v python3 || true)"
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MODE="public"
USE_TLS="${STOCKROOM_TLS:-1}"
ALLOW_FROM="${STOCKROOM_ALLOW_FROM:-}"
RESET_PW=0
RENEW_CERT=0

fail() { echo "ERROR: $*" >&2; exit 1; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --local) MODE="local" ;;
    --reset-password) RESET_PW=1 ;;
    --renew-cert) RENEW_CERT=1 ;;
    --no-tls) USE_TLS=0 ;;
    -h|--help) sed -n '2,11p' "${BASH_SOURCE[0]}"; exit 0 ;;
    *) fail "Opsi tidak dikenal: $1 (lihat: bash setup.sh --help)" ;;
  esac
  shift
done

[[ "$(id -u)" -eq 0 ]] || fail "Jalankan sebagai root: sudo bash setup.sh"
[[ -n "$PYTHON" ]] || fail "Python 3 belum tersedia. Install: apt-get install -y python3"
for f in app.py static/index.html static/login.html; do
  [[ -f "$HERE/$f" ]] || fail "$f tidak ditemukan. Ekstrak ZIP lalu jalankan setup.sh dari folder project."
done
[[ "$PORT" =~ ^[0-9]+$ ]] && (( PORT >= 1024 && PORT <= 65535 )) || fail "Port tidak valid: $PORT"
[[ -z "$ALLOW_FROM" || "$ALLOW_FROM" =~ ^[0-9a-fA-F:.]+(/[0-9]+)?$ ]] || fail "STOCKROOM_ALLOW_FROM harus berupa IP atau CIDR, misalnya 203.0.113.7"

# Perintah app.py yang menyentuh database harus memakai HOME yang sama dengan service.
app_cmd() { env -u XDG_DATA_HOME -u XDG_CACHE_HOME HOME="$ROOT_HOME" "$PYTHON" "$INSTALL_DIR/app.py" "$@"; }

echo "==> Memeriksa Python..."
"$PYTHON" - <<'PY'
import sys
if sys.version_info < (3, 8):
    raise SystemExit("Stockroom membutuhkan Python 3.8 atau lebih baru.")
print("Python", sys.version.split()[0])
PY

echo "==> Menghentikan service lama (jika ada)..."
systemctl stop "$APP" 2>/dev/null || true

echo "==> Memeriksa dukungan SFTP (opsional)..."
if command -v apt-get >/dev/null 2>&1; then
  if ! "$PYTHON" -c 'import paramiko' >/dev/null 2>&1; then
    apt-get install -y python3-paramiko >/dev/null 2>&1 || echo "INFO: Paramiko tidak terpasang; FTP/FTPS tetap tersedia. SFTP bisa diaktifkan nanti dengan: apt-get install -y python3-paramiko"
  fi
fi

echo "==> Memasang aplikasi ke $INSTALL_DIR..."
install -d -m 0755 "$INSTALL_DIR/static" "$DATA_ROOT"
install -d -m 0755 "$ROOT_HOME/.local/share/stockroom" "$ROOT_HOME/.cache/stockroom/thumbs"
install -m 0644 "$HERE/app.py" "$INSTALL_DIR/app.py"
install -m 0644 "$HERE/static/index.html" "$INSTALL_DIR/static/index.html"
install -m 0644 "$HERE/static/login.html" "$INSTALL_DIR/static/login.html"
chown -R root:root "$INSTALL_DIR"
chmod 0755 "$INSTALL_DIR" "$INSTALL_DIR/static"

# ---------------------------------------------------------------- password login
if [[ "$MODE" == "public" ]]; then
  echo "==> Memeriksa password login..."
  HAS_PW="$(app_cmd --auth-status 2>/dev/null || true)"
  NEW_PW="${STOCKROOM_PASSWORD:-}"
  if [[ -z "$NEW_PW" && ( "$HAS_PW" != "set" || "$RESET_PW" -eq 1 ) ]]; then
    [[ -t 0 ]] || fail "Butuh password login. Jalankan di terminal interaktif, atau: STOCKROOM_PASSWORD='password-panjang-anda' bash setup.sh"
    for attempt in 1 2 3; do
      read -rsp "Buat password login Stockroom (minimal 10 karakter): " P1; echo
      read -rsp "Ulangi password: " P2; echo
      if [[ "$P1" != "$P2" ]]; then echo "Password tidak sama, coba lagi."; continue; fi
      if (( ${#P1} < 10 )); then echo "Password minimal 10 karakter, coba lagi."; continue; fi
      NEW_PW="$P1"; break
    done
    [[ -n "$NEW_PW" ]] || fail "Password tidak diatur. Jalankan setup.sh lagi."
  fi
  if [[ -n "$NEW_PW" ]]; then
    STOCKROOM_NEW_PASSWORD="$NEW_PW" app_cmd --set-password || fail "Password tidak bisa disimpan."
  else
    echo "Password login yang sudah ada dipertahankan (ganti dengan: bash setup.sh --reset-password)."
  fi
  unset NEW_PW P1 P2 STOCKROOM_PASSWORD
fi

# ---------------------------------------------------------------- sertifikat HTTPS
detect_ips() {
  PUB_IP="$(curl -fsS --max-time 4 https://api.ipify.org 2>/dev/null || true)"
  [[ "$PUB_IP" =~ ^[0-9a-fA-F:.]+$ ]] || PUB_IP=""
  LOCAL_IPS="$(hostname -I 2>/dev/null || true)"
  SHOW_IP="${PUB_IP:-$(echo "$LOCAL_IPS" | awk '{print $1}')}"
  SHOW_IP="${SHOW_IP:-IP_VPS_ANDA}"
}
TLS_ARGS=""
CERT_FP=""
if [[ "$MODE" == "public" && "$USE_TLS" != "0" ]]; then
  echo "==> Menyiapkan sertifikat HTTPS..."
  command -v openssl >/dev/null 2>&1 || { apt-get install -y openssl >/dev/null 2>&1 || fail "openssl dibutuhkan untuk HTTPS. Install: apt-get install -y openssl"; }
  install -d -m 0700 "$TLS_DIR"
  need_cert=0
  [[ -s "$TLS_DIR/cert.pem" && -s "$TLS_DIR/key.pem" ]] || need_cert=1
  if [[ "$need_cert" -eq 0 ]] && ! openssl x509 -checkend 2592000 -noout -in "$TLS_DIR/cert.pem" >/dev/null 2>&1; then need_cert=1; fi
  [[ "$RENEW_CERT" -eq 1 ]] && need_cert=1
  detect_ips
  if [[ "$need_cert" -eq 1 ]]; then
    SAN="DNS:localhost,IP:127.0.0.1"
    for ip in $PUB_IP $LOCAL_IPS; do [[ "$ip" =~ ^[0-9a-fA-F:.]+$ ]] && SAN="$SAN,IP:$ip"; done
    openssl req -x509 -newkey rsa:3072 -nodes -sha256 -days 825 -subj "/CN=stockroom" \
      -addext "subjectAltName=$SAN" -keyout "$TLS_DIR/key.pem" -out "$TLS_DIR/cert.pem" >/dev/null 2>&1 \
      || fail "Gagal membuat sertifikat HTTPS."
    echo "Sertifikat baru dibuat (berlaku sekitar 2 tahun)."
  else
    echo "Sertifikat yang ada masih berlaku."
  fi
  chmod 0600 "$TLS_DIR/key.pem"; chmod 0644 "$TLS_DIR/cert.pem"
  CERT_FP="$(openssl x509 -noout -fingerprint -sha256 -in "$TLS_DIR/cert.pem" | cut -d= -f2)"
  TLS_ARGS="--tls-cert $TLS_DIR/cert.pem --tls-key $TLS_DIR/key.pem"
else
  detect_ips
fi
BIND_HOST="127.0.0.1"
[[ "$MODE" == "public" ]] && BIND_HOST="0.0.0.0"
SCHEME="http"
[[ -n "$TLS_ARGS" ]] && SCHEME="https"

# ---------------------------------------------------------------- service
echo "==> Membuat service systemd..."
cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Stockroom Microstock File Manager
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
Group=root
WorkingDirectory=$INSTALL_DIR
Environment=HOME=$ROOT_HOME
Environment=PYTHONUNBUFFERED=1
ExecStart=$PYTHON $INSTALL_DIR/app.py --root $DATA_ROOT --host $BIND_HOST --port $PORT $TLS_ARGS
Restart=on-failure
RestartSec=3
TimeoutStopSec=20
UMask=0022
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ReadWritePaths=$DATA_ROOT $ROOT_HOME/.local/share/stockroom $ROOT_HOME/.cache/stockroom

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$APP" >/dev/null
systemctl restart "$APP"

# ---------------------------------------------------------------- firewall
FW_NOTE=""
if [[ "$MODE" == "public" ]]; then
  if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
    if [[ -n "$ALLOW_FROM" ]]; then
      ufw allow from "$ALLOW_FROM" to any port "$PORT" proto tcp >/dev/null && FW_NOTE="Firewall ufw: port $PORT dibuka hanya untuk $ALLOW_FROM."
    else
      ufw allow "$PORT"/tcp >/dev/null && FW_NOTE="Firewall ufw: port $PORT dibuka untuk semua alamat. Untuk membatasi ke IP Anda saja: STOCKROOM_ALLOW_FROM=IP_ANDA bash setup.sh"
    fi
  else
    FW_NOTE="ufw tidak aktif di server ini. Kalau penyedia VPS punya firewall sendiri (security group), buka TCP port $PORT di sana."
  fi
fi

# ---------------------------------------------------------------- cek kesehatan
probe() {
  "$PYTHON" - "$SCHEME" "$PORT" <<'PY'
import ssl, sys, urllib.request
scheme, port = sys.argv[1], int(sys.argv[2])
ctx = ssl._create_unverified_context() if scheme == "https" else None
with urllib.request.urlopen("%s://127.0.0.1:%d/" % (scheme, port), timeout=2, context=ctx) as r:
    raise SystemExit(0 if r.status == 200 else 1)
PY
}

echo "==> Menunggu Stockroom aktif..."
for i in $(seq 1 20); do
  if probe >/dev/null 2>&1; then break; fi
  sleep 1
done

if ! probe 2>/tmp/stockroom-probe.err; then
  echo
  echo "Stockroom belum merespons: $(tail -n 1 /tmp/stockroom-probe.err 2>/dev/null)"
  systemctl status "$APP" --no-pager || true
  journalctl -u "$APP" -n 50 --no-pager || true
  fail "Service gagal aktif. Periksa log di atas."
fi

echo
echo "=============================================="
echo " STOCKROOM BERHASIL DIPASANG / DIPERBARUI"
echo "=============================================="
echo "Versi       : 1.7.0"
echo "Folder data : $DATA_ROOT"
echo "Service     : systemctl status stockroom   |   log: journalctl -u stockroom -f"
echo
if [[ "$MODE" == "public" ]]; then
  echo "Buka di browser mana saja:"
  echo "  $SCHEME://$SHOW_IP:$PORT"
  echo
  if [[ "$SCHEME" == "https" ]]; then
    echo "Saat pertama kali, browser akan memperingatkan sertifikat (wajar: sertifikat dibuat sendiri,"
    echo "bukan dari otoritas publik). Lanjutkan saja; lalu masuk dengan password yang tadi dibuat."
    echo "  Safari : Tampilkan Detail > kunjungi situs web"
    echo "  Chrome : Lanjutan > Lanjutkan ke $SHOW_IP"
    echo "Sidik jari sertifikat (SHA-256), untuk dicocokkan bila perlu:"
    echo "  $CERT_FP"
  else
    echo "PERINGATAN: HTTPS dimatikan. Password dan data dikirim TANPA enkripsi lewat internet."
  fi
  echo
  [[ -n "$FW_NOTE" ]] && echo "$FW_NOTE" && echo
  echo "Ganti password : sudo bash setup.sh --reset-password"
  echo "Kembali ke mode lokal (SSH tunnel) : sudo bash setup.sh --local"
else
  echo "Mode lokal: hanya bisa diakses dari server itu sendiri. Di laptop/Mac, jalankan:"
  echo "  ssh -N -L $PORT:127.0.0.1:$PORT root@IP_VPS_ANDA"
  echo "lalu buka http://127.0.0.1:$PORT"
  [[ "$(app_cmd --auth-status 2>/dev/null || true)" == "set" ]] && echo "Catatan: login password tetap aktif karena password sudah pernah dibuat."
fi
echo
echo "Database tanda upload tetap disimpan di $ROOT_HOME/.local/share/stockroom."
