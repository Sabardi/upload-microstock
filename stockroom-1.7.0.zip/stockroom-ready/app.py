#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stockroom - manajer file upload microstock.

Satu file, tanpa dependensi wajib (hanya Python 3.8+).
Opsional: Pillow (thumbnail cepat) dan ffmpeg/ffprobe (thumbnail & info video).
"""

import argparse
import base64
import getpass
import secrets
import hashlib
import hmac
import json
import mimetypes
import os
import posixpath
import re
import shutil
import socket
import ssl
import ftplib
import sqlite3
import subprocess
import sys
import threading
import time
import traceback
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse, quote

try:
    from PIL import Image, ImageOps

    Image.MAX_IMAGE_PIXELS = None
    HAS_PIL = True
except Exception:  # pragma: no cover
    HAS_PIL = False

HAS_FFMPEG = bool(shutil.which("ffmpeg"))
HAS_FFPROBE = bool(shutil.which("ffprobe"))
VERSION = "1.7.0"

HERE = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share") / "stockroom"
CACHE_DIR = Path(os.environ.get("XDG_CACHE_HOME") or Path.home() / ".cache") / "stockroom" / "thumbs"

DEFAULT_MARKETS = [
    {"name": "Shutterstock", "color": "#E5484D"},
    {"name": "Adobe Stock", "color": "#7C5CFC"},
    {"name": "Freepik", "color": "#2F80ED"},
    {"name": "Dreamstime", "color": "#2CA66B"},
    {"name": "Vecteezy", "color": "#F08A24"},
    {"name": "Depositphotos", "color": "#0FA3B1"},
    {"name": "123RF", "color": "#D6409F"},
    {"name": "Pond5", "color": "#8B7355"},
]

IMG_EXT = {"jpg", "jpeg", "png", "webp", "gif", "bmp", "tif", "tiff"}
VID_EXT = {"mp4", "mov", "m4v", "webm", "mkv", "avi", "mpg", "mpeg", "mts"}
VEC_EXT = {"svg", "eps", "ai", "pdf"}
NATIVE_IMG = {"jpg", "jpeg", "png", "webp", "gif", "bmp", "svg"}

STATE = {"root": "", "password": None, "any_host": False, "tls": False, "tls_ctx": None}


def kind_of(ext):
    if ext in VID_EXT:
        return "video"
    if ext in VEC_EXT:
        return "vector"
    if ext in IMG_EXT:
        return "image"
    return "file"


class ApiError(Exception):
    def __init__(self, status, msg):
        super().__init__(msg)
        self.status = status
        self.msg = msg


# --------------------------------------------------------------------------
# Penyimpanan tanda upload (SQLite)
# --------------------------------------------------------------------------
class Store:
    def __init__(self):
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(str(DATA_DIR), 0o700)
        except OSError:
            pass
        self.lock = threading.RLock()
        self.db = sqlite3.connect(str(DATA_DIR / "stockroom.db"), check_same_thread=False)
        self.db.executescript(
            """
            CREATE TABLE IF NOT EXISTS marks(
                path   TEXT NOT NULL,
                market TEXT NOT NULL,
                ts     INTEGER NOT NULL,
                PRIMARY KEY(path, market)
            );
            CREATE TABLE IF NOT EXISTS settings(
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS remote_marks(
                path       TEXT NOT NULL,
                profile_id TEXT NOT NULL,
                ts         INTEGER NOT NULL,
                PRIMARY KEY(path, profile_id)
            );
            """
        )
        self.db.commit()
        try:
            os.chmod(str(DATA_DIR / "stockroom.db"), 0o600)
        except OSError:
            pass

    def get(self, key, default=None):
        with self.lock:
            r = self.db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return json.loads(r[0]) if r else default

    def put(self, key, value):
        with self.lock:
            self.db.execute(
                "INSERT INTO settings(key,value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, json.dumps(value)),
            )
            self.db.commit()

    def marks_in_dir(self, rel):
        with self.lock:
            if rel:
                prefix = rel + "/"
                rows = self.db.execute(
                    "SELECT path, market FROM marks WHERE path>=? AND path<?",
                    (prefix, rel + "0"),
                ).fetchall()
            else:
                prefix = ""
                rows = self.db.execute("SELECT path, market FROM marks WHERE path NOT LIKE '%/%'").fetchall()
        out = {}
        for p, m in rows:
            name = p[len(prefix):]
            if "/" in name:
                continue
            out.setdefault(name, []).append(m)
        return out

    def all_marks(self):
        with self.lock:
            rows = self.db.execute("SELECT path, market FROM marks").fetchall()
        out = {}
        for p, m in rows:
            out.setdefault(p, set()).add(m)
        return out

    def apply(self, files, markets, action):
        now = int(time.time())
        with self.lock:
            c = self.db
            if action == "add":
                c.executemany(
                    "INSERT OR IGNORE INTO marks(path,market,ts) VALUES(?,?,?)",
                    [(f, m, now) for f in files for m in markets],
                )
            elif action == "remove":
                c.executemany(
                    "DELETE FROM marks WHERE path=? AND market=?",
                    [(f, m) for f in files for m in markets],
                )
            elif action == "clear":
                c.executemany("DELETE FROM marks WHERE path=?", [(f,) for f in files])
            c.commit()

    def remote_marks_in_dir(self, rel):
        with self.lock:
            if rel:
                prefix = rel + "/"
                rows = self.db.execute(
                    "SELECT path, profile_id FROM remote_marks WHERE path>=? AND path<?",
                    (prefix, rel + "0"),
                ).fetchall()
            else:
                prefix = ""
                rows = self.db.execute("SELECT path, profile_id FROM remote_marks WHERE path NOT LIKE '%/%'").fetchall()
        out = {}
        for path, profile_id in rows:
            name = path[len(prefix):]
            if "/" not in name:
                out.setdefault(name, []).append(profile_id)
        return out

    def mark_remote_upload(self, rel, profile_id):
        with self.lock:
            self.db.execute(
                "INSERT OR REPLACE INTO remote_marks(path,profile_id,ts) VALUES(?,?,?)",
                (rel, profile_id, int(time.time())),
            )
            self.db.commit()

    def delete_marks(self, rel):
        with self.lock:
            for table in ("marks", "remote_marks"):
                self.db.execute("DELETE FROM %s WHERE path=?" % table, (rel,))
                self.db.execute("DELETE FROM %s WHERE path>=? AND path<?" % table, (rel + "/", rel + "0"))
            self.db.commit()

    def rename_marks(self, old, new):
        with self.lock:
            c = self.db
            c.execute("DELETE FROM marks WHERE path=?", (new,))
            c.execute("DELETE FROM marks WHERE path>=? AND path<?", (new + "/", new + "0"))
            c.execute("UPDATE marks SET path=? WHERE path=?", (new, old))
            rows = c.execute(
                "SELECT path, market FROM marks WHERE path>=? AND path<?", (old + "/", old + "0")
            ).fetchall()
            c.executemany(
                "UPDATE marks SET path=? WHERE path=? AND market=?",
                [(new + p[len(old):], p, m) for p, m in rows],
            )
            c.execute("DELETE FROM remote_marks WHERE path=?", (new,))
            c.execute("DELETE FROM remote_marks WHERE path>=? AND path<?", (new + "/", new + "0"))
            c.execute("UPDATE remote_marks SET path=? WHERE path=?", (new, old))
            remote_rows = c.execute(
                "SELECT path, profile_id FROM remote_marks WHERE path>=? AND path<?", (old + "/", old + "0")
            ).fetchall()
            c.executemany(
                "UPDATE remote_marks SET path=? WHERE path=? AND profile_id=?",
                [(new + p[len(old):], p, pid) for p, pid in remote_rows],
            )
            c.commit()


store = Store()


def get_markets():
    m = store.get("markets")
    return m if m else DEFAULT_MARKETS


def get_rule():
    return store.get("done_rule", "all")


def is_done(ms, mset, rule):
    if rule == "any":
        return bool(ms & mset)
    return bool(mset) and mset <= ms


# --------------------------------------------------------------------------
# Path helper (semua path dari klien relatif terhadap root)
# --------------------------------------------------------------------------
def norm_rel(rel):
    rel = (rel or "").replace("\\", "/")
    if "\x00" in rel:
        raise ApiError(400, "Path tidak valid.")
    return posixpath.normpath("/" + rel).lstrip("/")


def abs_of(rel):
    rel = norm_rel(rel)
    root = STATE["root"]
    ap = os.path.join(root, *rel.split("/")) if rel else root
    real = os.path.realpath(ap)
    if real != root and not real.startswith(root + os.sep):
        raise ApiError(403, "Lokasi berada di luar folder utama.")
    return rel, ap


def join_rel(a, b):
    return b if not a else a + "/" + b


def valid_name(name):
    name = (name or "").strip()
    if not name or name in (".", "..") or "/" in name or "\\" in name or "\x00" in name:
        raise ApiError(400, "Nama tidak valid.")
    if len(name.encode("utf-8")) > 255:
        raise ApiError(400, "Nama terlalu panjang.")
    return name


def unique_dest(dirpath, name):
    base, ext = os.path.splitext(name)
    cand, i = name, 1
    while os.path.lexists(os.path.join(dirpath, cand)):
        cand = "%s (%d)%s" % (base, i, ext)
        i += 1
    return cand


def dir_size(path):
    total = 0
    for dp, _dn, fn in os.walk(path):
        for f in fn:
            try:
                total += os.lstat(os.path.join(dp, f)).st_size
            except OSError:
                pass
    return total


def expand_files(rel, ap):
    if os.path.isdir(ap) and not os.path.islink(ap):
        out = []
        for dp, dn, fn in os.walk(ap):
            dn[:] = [d for d in dn if not d.startswith(".")]
            for f in fn:
                if f.startswith("."):
                    continue
                out.append(os.path.relpath(os.path.join(dp, f), STATE["root"]).replace(os.sep, "/"))
        return out
    return [rel]


# --------------------------------------------------------------------------
# Pemindai library (hitung total, yang sudah terupload, dll.) di latar belakang
# --------------------------------------------------------------------------
class Scanner:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.pending = False
        self.result = None

    def start(self):
        with self.lock:
            if self.running:
                self.pending = True
                return
            self.running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while True:
            try:
                self.result = self._scan()
            except Exception:
                traceback.print_exc()
            with self.lock:
                if self.pending:
                    self.pending = False
                    continue
                self.running = False
                return

    def _scan(self):
        root = STATE["root"]
        marks = store.all_marks()
        files = size = 0
        marked = []
        for dp, dn, fn in os.walk(root):
            dn[:] = [d for d in dn if not d.startswith(".")]
            for f in fn:
                if f.startswith("."):
                    continue
                ap = os.path.join(dp, f)
                try:
                    st = os.stat(ap)
                except OSError:
                    continue
                rel = os.path.relpath(ap, root).replace(os.sep, "/")
                files += 1
                size += st.st_size
                ms = marks.get(rel)
                if ms:
                    marked.append((rel, st.st_size, int(st.st_mtime), ms))
        return {"root": root, "files": files, "bytes": size, "marked": marked, "at": time.time()}


scanner = Scanner()


def summarize(res, rule):
    mset = {m["name"] for m in get_markets()}
    done = []
    partial = 0
    for rel, sz, mt, ms in res["marked"]:
        if is_done(ms, mset, rule):
            done.append((rel, sz, mt, ms))
        else:
            partial += 1
    return done, partial


# --------------------------------------------------------------------------
# Thumbnail
# --------------------------------------------------------------------------
THUMB_SEM = threading.Semaphore(3)


def make_thumb(ap, w):
    st = os.stat(ap)
    key = hashlib.sha1(("%s|%d|%d|%d" % (ap, st.st_size, st.st_mtime_ns, w)).encode()).hexdigest()
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    for ext in ("jpg", "png"):
        c = CACHE_DIR / ("%s.%s" % (key, ext))
        if c.exists():
            return c
    ext = os.path.splitext(ap)[1].lower().lstrip(".")
    k = kind_of(ext)
    with THUMB_SEM:
        if k == "video":
            if not HAS_FFMPEG:
                return None
            out = CACHE_DIR / (key + ".jpg")
            tmp = CACHE_DIR / (key + ".part.jpg")
            for ss in ("1", "0"):
                try:
                    r = subprocess.run(
                        ["ffmpeg", "-v", "error", "-y", "-ss", ss, "-i", ap, "-frames:v", "1",
                         "-vf", "scale=%d:-2" % w, "-q:v", "5", str(tmp)],
                        capture_output=True, timeout=40,
                    )
                except (subprocess.TimeoutExpired, OSError):
                    return None
                if r.returncode == 0 and tmp.exists() and tmp.stat().st_size > 0:
                    os.replace(tmp, out)
                    return out
            return None
        if HAS_PIL and ext != "svg":
            try:
                im = Image.open(ap)
                if im.format == "JPEG":
                    im.draft("RGB", (w * 2, w * 2))
                im = ImageOps.exif_transpose(im)
                im.thumbnail((w, w))
                alpha = im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info)
                if alpha:
                    out = CACHE_DIR / (key + ".png")
                    tmp = CACHE_DIR / (key + ".part.png")
                    im.convert("RGBA").save(tmp, "PNG")
                else:
                    out = CACHE_DIR / (key + ".jpg")
                    tmp = CACHE_DIR / (key + ".part.jpg")
                    im.convert("RGB").save(tmp, "JPEG", quality=82)
                os.replace(tmp, out)
                return out
            except Exception:
                return None
    return None


# --------------------------------------------------------------------------
# API
# --------------------------------------------------------------------------
def api_config(q, b):
    return {
        "root": STATE["root"],
        "markets": get_markets(),
        "remote_profiles": [public_profile(x) for x in get_remote_profiles()],
        "done_rule": get_rule(),
        "warn_pct": store.get("warn_pct", 10),
        "has_pillow": HAS_PIL,
        "has_ffmpeg": HAS_FFMPEG,
        "auth": auth_enabled(),
        "tls": STATE["tls"],
        "version": VERSION,
    }


def api_list(q, b):
    rel, ap = abs_of(q.get("path", [""])[0])
    if not os.path.isdir(ap):
        raise ApiError(404, "Folder tidak ditemukan.")
    marks = store.marks_in_dir(rel)
    remote_marks = store.remote_marks_in_dir(rel)
    items = []
    try:
        entries = list(os.scandir(ap))
    except OSError as e:
        raise ApiError(403, "Folder tidak bisa dibuka: %s" % (e.strerror or e))
    for e in entries:
        if e.name.startswith("."):
            continue
        try:
            is_dir = e.is_dir()
            st = e.stat()
        except OSError:
            continue
        if is_dir:
            n = 0
            try:
                with os.scandir(e.path) as sub:
                    for s in sub:
                        if not s.name.startswith("."):
                            n += 1
            except OSError:
                pass
            items.append({"name": e.name, "dir": True, "mtime": int(st.st_mtime), "count": n})
        else:
            ext = os.path.splitext(e.name)[1].lower().lstrip(".")
            items.append({
                "name": e.name, "dir": False, "size": st.st_size, "mtime": int(st.st_mtime),
                "ext": ext, "kind": kind_of(ext), "marks": sorted(marks.get(e.name, [])),
                "account_marks": sorted(remote_marks.get(e.name, [])),
            })
    return {"path": rel, "items": items}


def api_storage(q, b):
    du = shutil.disk_usage(STATE["root"])
    out = {"total": du.total, "used": du.total - du.free, "free": du.free, "scanning": scanner.running}
    res = scanner.result
    if res is None and not scanner.running:
        scanner.start()
        out["scanning"] = True
    if res:
        done, partial = summarize(res, get_rule())
        out.update({
            "lib_bytes": res["bytes"],
            "lib_files": res["files"],
            "reclaim_bytes": sum(x[1] for x in done),
            "reclaim_files": len(done),
            "partial_files": partial,
            "pending_files": res["files"] - len(res["marked"]),
            "scanned_at": res["at"],
        })
    return out


def api_reclaimable(q, b):
    rule = q.get("rule", [get_rule()])[0]
    if rule not in ("all", "any"):
        rule = "all"
    order = q.get("sort", ["size"])[0]
    res = scanner.result
    if res is None:
        scanner.start()
        return {"scanning": True, "items": [], "count": 0, "bytes": 0}
    done, _ = summarize(res, rule)
    if order == "old":
        done.sort(key=lambda x: x[2])
    else:
        done.sort(key=lambda x: -x[1])
    items = [{"path": r, "size": s, "mtime": m, "marks": sorted(ms)} for r, s, m, ms in done[:5000]]
    return {"scanning": scanner.running, "items": items, "count": len(done), "bytes": sum(x[1] for x in done)}


def api_info(q, b):
    rel, ap = abs_of(q.get("path", [""])[0])
    if not os.path.isfile(ap):
        raise ApiError(404, "File tidak ditemukan.")
    st = os.stat(ap)
    ext = os.path.splitext(ap)[1].lower().lstrip(".")
    info = {"name": os.path.basename(ap), "size": st.st_size, "mtime": int(st.st_mtime), "ext": ext, "kind": kind_of(ext)}
    if HAS_PIL and ext in IMG_EXT:
        try:
            with Image.open(ap) as im:
                info["w"], info["h"] = im.size
        except Exception:
            pass
    elif info["kind"] == "video" and HAS_FFPROBE:
        try:
            r = subprocess.run(
                ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                 "stream=width,height,duration", "-of", "json", ap],
                capture_output=True, timeout=10,
            )
            s = json.loads(r.stdout or b"{}").get("streams", [{}])[0]
            info["w"], info["h"] = s.get("width"), s.get("height")
            if s.get("duration"):
                info["duration"] = float(s["duration"])
        except Exception:
            pass
    return info


def api_mark(q, b):
    action = b.get("action")
    if action not in ("add", "remove", "clear"):
        raise ApiError(400, "Aksi tidak dikenal.")
    markets = [str(m)[:60] for m in (b.get("markets") or [])]
    if action != "clear" and not markets:
        raise ApiError(400, "Pilih marketplace.")
    files = []
    for p in b.get("paths") or []:
        rel, ap = abs_of(p)
        if rel == "":
            continue
        files.extend(expand_files(rel, ap))
    store.apply(files, markets, action)
    scanner.start()
    return {"ok": True, "files": len(files)}


def _transfer(b, copy):
    drel, dap = abs_of(b.get("dest", ""))
    if not os.path.isdir(dap):
        raise ApiError(404, "Folder tujuan tidak ada.")
    done = renamed = skipped = 0
    errors = []
    dreal = os.path.realpath(dap)
    for p in b.get("paths") or []:
        srel, sap = abs_of(p)
        name = os.path.basename(sap)
        if srel == "":
            errors.append("Folder utama tidak bisa dipindah.")
            continue
        sreal = os.path.realpath(sap)
        if not copy and os.path.dirname(sreal) == dreal:
            skipped += 1
            continue
        if os.path.isdir(sap) and (dreal == sreal or dreal.startswith(sreal + os.sep)):
            errors.append("%s: tidak bisa dimasukkan ke dalam dirinya sendiri." % name)
            continue
        new_name = unique_dest(dap, name)
        target = os.path.join(dap, new_name)
        try:
            if copy:
                if os.path.isdir(sap):
                    shutil.copytree(sap, target)
                else:
                    shutil.copy2(sap, target)
            else:
                shutil.move(sap, target)
                store.rename_marks(srel, join_rel(drel, new_name))
            done += 1
            if new_name != name:
                renamed += 1
        except (OSError, shutil.Error) as e:
            errors.append("%s: %s" % (name, getattr(e, "strerror", None) or e))
    scanner.start()
    return {"done": done, "renamed": renamed, "skipped": skipped, "errors": errors}


def api_move(q, b):
    return _transfer(b, False)


def api_copy(q, b):
    return _transfer(b, True)


def api_delete(q, b):
    n = freed = 0
    errors = []
    for p in b.get("paths") or []:
        rel, ap = abs_of(p)
        if rel == "":
            errors.append("Folder utama tidak bisa dihapus.")
            continue
        try:
            if os.path.isdir(ap) and not os.path.islink(ap):
                sz = dir_size(ap)
                shutil.rmtree(ap)
            else:
                sz = os.lstat(ap).st_size
                os.remove(ap)
            store.delete_marks(rel)
            n += 1
            freed += sz
        except OSError as e:
            errors.append("%s: %s" % (os.path.basename(ap), e.strerror or e))
    scanner.start()
    return {"deleted": n, "freed": freed, "errors": errors}


def api_mkdir(q, b):
    rel, ap = abs_of(b.get("path", ""))
    name = valid_name(b.get("name"))
    target = os.path.join(ap, name)
    if os.path.lexists(target):
        raise ApiError(409, "Nama sudah dipakai.")
    try:
        os.mkdir(target)
    except OSError as e:
        raise ApiError(400, e.strerror or str(e))
    return {"ok": True}


def api_rename(q, b):
    rel, ap = abs_of(b.get("path", ""))
    if rel == "":
        raise ApiError(400, "Folder utama tidak bisa diganti namanya.")
    name = valid_name(b.get("name"))
    target = os.path.join(os.path.dirname(ap), name)
    if os.path.lexists(target) and os.path.realpath(target) != os.path.realpath(ap):
        raise ApiError(409, "Nama sudah dipakai.")
    try:
        os.rename(ap, target)
    except OSError as e:
        raise ApiError(400, e.strerror or str(e))
    parent = posixpath.dirname(rel)
    store.rename_marks(rel, join_rel(parent, name))
    scanner.start()
    return {"ok": True}


def api_settings(q, b):
    if "markets" in b:
        seen, out = set(), []
        for m in b["markets"][:24]:
            name = str(m.get("name", "")).strip()[:40]
            color = str(m.get("color", ""))
            if not name or name.lower() in seen:
                continue
            if not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
                color = "#888888"
            seen.add(name.lower())
            out.append({"name": name, "color": color})
        if not out:
            raise ApiError(400, "Minimal satu marketplace.")
        store.put("markets", out)
    if b.get("done_rule") in ("all", "any"):
        store.put("done_rule", b["done_rule"])
    if "warn_pct" in b:
        try:
            store.put("warn_pct", max(1, min(50, int(b["warn_pct"]))))
        except (TypeError, ValueError):
            pass
    if b.get("root") and os.path.realpath(os.path.expanduser(b["root"])) != STATE["root"]:
        new = os.path.realpath(os.path.expanduser(b["root"]))
        if not os.path.isdir(new):
            raise ApiError(400, "Folder utama tidak ditemukan.")
        STATE["root"] = new
        store.put("root", new)
        scanner.result = None
    scanner.start()
    return api_config(q, b)


def api_rescan(q, b):
    scanner.start()
    return {"ok": True}



# --------------------------------------------------------------------------
# FTP / FTPS / SFTP: profil situs, penjelajah folder remote, dan antrean transfer
# --------------------------------------------------------------------------
import calendar
import errno
import stat as stat_mod
from collections import deque

try:
    import paramiko as _paramiko
except Exception:  # pragma: no cover
    _paramiko = None

FTP_LOG = deque(maxlen=800)
FTP_LOG_SEQ = [0]
TQ = {"items": [], "seq": 0, "paused": False, "workers": 2, "policy": "resume", "running": 0, "started": False}
TQ_COND = threading.Condition(threading.RLock())
MAX_WORKERS = 5
POLICIES = ("resume", "overwrite", "skip", "rename")
BLOCK = 256 * 1024


class TransferCancelled(Exception):
    pass


class PermanentError(Exception):
    pass


def ftp_log(msg, level="info"):
    with TQ_COND:
        FTP_LOG_SEQ[0] += 1
        FTP_LOG.append({"n": FTP_LOG_SEQ[0], "t": int(time.time()), "l": level, "m": str(msg)[:400]})


def public_profile(profile):
    out = {k: profile.get(k, "") for k in ("id", "name", "platform", "protocol", "host", "port", "username", "remote_dir")}
    out["verify_tls"] = profile.get("verify_tls", True) is not False
    return out


def get_remote_profiles():
    return store.get("remote_profiles", []) or []


def find_profile(pid):
    p = next((x for x in get_remote_profiles() if x.get("id") == str(pid)), None)
    if not p:
        raise ApiError(404, "Situs tidak ditemukan. Pilih atau tambahkan situs dulu.")
    return p


def _hostkey_tag(host, port):
    return "%s:%s" % (host, port)


def save_remote_profile(data):
    name = str(data.get("name", "")).strip()[:60]
    platform = str(data.get("platform", "custom")).strip().lower()
    protocol = str(data.get("protocol", "ftps")).strip().lower()
    host = str(data.get("host", "")).strip()[:255]
    username = str(data.get("username", "")).strip()[:255]
    password = str(data.get("password", ""))
    remote_dir = str(data.get("remote_dir", "")).strip()[:500]
    if protocol not in ("ftp", "ftps", "sftp"):
        raise ApiError(400, "Protokol harus FTP, FTPS, atau SFTP.")
    if not name or not host or not username:
        raise ApiError(400, "Nama, host, dan username wajib diisi.")
    try:
        port = int(data.get("port") or (22 if protocol == "sftp" else 21))
    except (TypeError, ValueError):
        raise ApiError(400, "Port tidak valid.")
    if not 1 <= port <= 65535:
        raise ApiError(400, "Port harus antara 1 sampai 65535.")
    profiles = get_remote_profiles()
    pid = str(data.get("id") or uuid.uuid4().hex)
    old = next((x for x in profiles if x.get("id") == pid), None)
    # Saat mengedit, password kosong berarti pertahankan password lama.
    if old and not password:
        password = old.get("password", "")
    if not password:
        raise ApiError(400, "Password wajib diisi untuk profil baru.")
    profile = {"id": pid, "name": name, "platform": platform, "protocol": protocol,
               "host": host, "port": port, "username": username, "password": password,
               "remote_dir": remote_dir, "verify_tls": data.get("verify_tls", True) is not False}
    if old:
        profiles = [profile if x.get("id") == pid else x for x in profiles]
    else:
        profiles.append(profile)
    store.put("remote_profiles", profiles[:30])
    # Kunci host SFTP dilupakan bila diminta atau bila host/port berubah.
    if data.get("reset_hostkey") or (old and (old.get("host"), old.get("port")) != (host, port)):
        keys = store.get("sftp_hostkeys", {}) or {}
        for h, p in {(host, port), (old.get("host"), old.get("port")) if old else (host, port)}:
            keys.pop(_hostkey_tag(h, p), None)
        store.put("sftp_hostkeys", keys)
    BROWSE_DROP(pid)
    return public_profile(profile)


class _FTPTLS(ftplib.FTP_TLS):
    """FTPS dengan penggunaan ulang sesi TLS di kanal data (diwajibkan banyak server)."""

    def ntransfercmd(self, cmd, rest=None):
        conn, size = ftplib.FTP.ntransfercmd(self, cmd, rest)
        if self._prot_p:
            conn = self.context.wrap_socket(conn, server_hostname=self.host, session=self.sock.session)
        return conn, size


def _tls_context(profile):
    ctx = ssl.create_default_context()
    if profile.get("verify_tls", True) is False:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    return ctx


def _tofu_policy(paramiko, host, port):
    class TOFU(paramiko.MissingHostKeyPolicy):
        def missing_host_key(self, client, hostname, key):
            fp = hashlib.sha256(key.asbytes()).hexdigest()
            tag = _hostkey_tag(host, port)
            keys = store.get("sftp_hostkeys", {}) or {}
            old = keys.get(tag)
            if old is None:
                keys[tag] = fp
                store.put("sftp_hostkeys", keys)
                ftp_log("Host SFTP %s dipercaya pada koneksi pertama (SHA256 %s…)." % (tag, fp[:16]))
                return
            if old != fp:
                e = paramiko.SSHException(
                    "Kunci host %s berubah dari yang tersimpan. Server mungkin diganti atau ada penyadapan. "
                    "Kalau perubahan ini wajar, buka Kelola situs, Edit, centang reset kunci host, lalu simpan." % tag)
                e.permanent = True
                raise e
    return TOFU()


def connect_remote(profile):
    proto = profile.get("protocol", "ftps")
    host, port = profile["host"], int(profile.get("port") or (22 if proto == "sftp" else 21))
    user, password = profile["username"], profile["password"]
    if proto == "sftp":
        if _paramiko is None:
            raise ApiError(400, "Modul SFTP belum tersedia. Jalankan: apt install python3-paramiko")
        ssh = _paramiko.SSHClient()
        try:
            ssh.load_system_host_keys()
        except Exception:
            pass
        ssh.set_missing_host_key_policy(_tofu_policy(_paramiko, host, port))
        ssh.connect(hostname=host, port=port, username=user, password=password,
                    timeout=30, banner_timeout=30, auth_timeout=30,
                    look_for_keys=False, allow_agent=False)
        try:
            ssh.get_transport().set_keepalive(30)
        except Exception:
            pass
        return ("sftp", ssh.open_sftp(), ssh)
    if proto == "ftps":
        ftp = _FTPTLS(context=_tls_context(profile), timeout=30)
        ftp.connect(host, port, timeout=30)
        ftp.login(user, password)
        ftp.prot_p()
        return ("ftp", ftp, None)
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(host, port, timeout=30)
    ftp.login(user, password)
    return ("ftp", ftp, None)


_LIST_RE = re.compile(r"^([\-dlsbcp])[rwxsStT\-]{9}[+@.]?\s+\d+\s+\S+\s+\S+\s+(\d+)\s+(\w{3}\s+\d+\s+[\d:]+)\s+(.+)$")


def _mlsd_time(v):
    try:
        return calendar.timegm(time.strptime(v[:14], "%Y%m%d%H%M%S"))
    except Exception:
        return 0


class RemoteConn:
    """Satu koneksi ke server remote dengan operasi seragam untuk FTP/FTPS dan SFTP."""

    def __init__(self, profile):
        self.profile = dict(profile)
        self.kind, self.client, self.extra = connect_remote(profile)
        self.made = set()
        self.mlsd = None
        self.data_conn = None
        self.last = time.time()
        try:
            self.home = self.client.normalize(".") if self.kind == "sftp" else (self.client.pwd() or "/")
        except Exception:
            self.home = "/"

    def close(self):
        try:
            if self.kind == "ftp":
                self.client.quit()
            else:
                self.client.close()
        except Exception:
            try:
                self.client.close()
            except Exception:
                pass
        if self.extra is not None:
            try:
                self.extra.close()
            except Exception:
                pass

    def abort(self):
        """Putuskan koneksi dari thread lain agar transfer yang sedang menunggu langsung berhenti."""
        for sock in (self.data_conn, getattr(self.client, "sock", None)):
            try:
                if sock is not None:
                    sock.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
        if self.kind == "sftp":
            try:
                self.extra.get_transport().close()
            except Exception:
                pass

    def alive(self):
        try:
            if self.kind == "sftp":
                self.client.stat(".")
            else:
                self.client.voidcmd("NOOP")
            return True
        except Exception:
            return False

    def abs(self, path):
        path = (path or "").strip()
        if not path:
            return self.home
        if not path.startswith("/"):
            path = posixpath.join(self.home, path)
        return posixpath.normpath(path)

    def listdir(self, path):
        out = []
        if self.kind == "sftp":
            for a in self.client.listdir_attr(path):
                if a.filename in (".", ".."):
                    continue
                out.append({"name": a.filename, "dir": stat_mod.S_ISDIR(a.st_mode or 0),
                            "size": a.st_size or 0, "mtime": int(a.st_mtime or 0)})
            return out
        c = self.client
        c.cwd(path)
        if self.mlsd is not False:
            try:
                for name, facts in c.mlsd():
                    t = facts.get("type", "").lower()
                    if t in ("cdir", "pdir") or name in (".", ".."):
                        continue
                    out.append({"name": name, "dir": t == "dir", "size": int(facts.get("size") or 0),
                                "mtime": _mlsd_time(facts.get("modify", ""))})
                self.mlsd = True
                return out
            except ftplib.error_perm as e:
                if not str(e).startswith(("500", "501", "502", "504")):
                    raise
                self.mlsd = False
                out = []
        lines = []
        c.retrlines("LIST", lines.append)
        for ln in lines:
            m = _LIST_RE.match(ln.strip())
            if not m:
                continue
            kind, size, _d, name = m.groups()
            if " -> " in name:
                name = name.split(" -> ")[0]
            if name in (".", ".."):
                continue
            out.append({"name": name, "dir": kind == "d", "size": int(size), "mtime": 0})
        return out

    def isdir(self, path):
        try:
            if self.kind == "sftp":
                return stat_mod.S_ISDIR(self.client.stat(path).st_mode)
            cur = self.client.pwd()
            self.client.cwd(path)
            self.client.cwd(cur)
            return True
        except (OSError, ftplib.error_perm):
            return False

    def size(self, path):
        """Ukuran file remote, atau None bila tidak ada."""
        try:
            if self.kind == "sftp":
                st = self.client.stat(path)
                return None if stat_mod.S_ISDIR(st.st_mode) else st.st_size
            self.client.voidcmd("TYPE I")
            return int(self.client.sendcmd("SIZE " + path).split()[1])
        except ftplib.error_perm as e:
            if str(e).startswith(("500", "501", "502")):
                for it in self.listdir(posixpath.dirname(path) or "/"):
                    if it["name"] == posixpath.basename(path) and not it["dir"]:
                        return it["size"]
            return None
        except OSError as e:
            if e.errno == errno.ENOENT:
                return None
            raise

    def mkdir(self, path):
        if self.kind == "sftp":
            self.client.mkdir(path)
        else:
            self.client.mkd(path)

    def mkdirs(self, path):
        if path in self.made or path in ("", "/", "."):
            return
        cur = "/"
        for part in [p for p in path.split("/") if p]:
            cur = posixpath.join(cur, part)
            if cur in self.made:
                continue
            if not self.isdir(cur):
                try:
                    self.mkdir(cur)
                except (OSError, ftplib.error_perm):
                    if not self.isdir(cur):
                        raise
            self.made.add(cur)

    def rename(self, a, b):
        self.client.rename(a, b)

    def remove(self, path):
        if self.kind == "sftp":
            self.client.remove(path)
        else:
            self.client.delete(path)

    def rmdir(self, path):
        if self.kind == "sftp":
            self.client.rmdir(path)
        else:
            self.client.rmd(path)

    def rmtree(self, path, depth=0):
        if depth > 30:
            raise PermanentError("Folder terlalu dalam.")
        for e in self.listdir(path):
            p = posixpath.join(path, e["name"])
            if e["dir"]:
                self.rmtree(p, depth + 1)
            else:
                self.remove(p)
        self.rmdir(path)

    def store(self, local, remote, offset, cb, fin=None):
        with open(local, "rb") as fh:
            if offset:
                fh.seek(offset)
            if self.kind == "sftp":
                with self.client.open(remote, "r+b" if offset else "wb") as rf:
                    if offset:
                        rf.seek(offset)
                    rf.set_pipelined(True)
                    while True:
                        buf = fh.read(BLOCK)
                        if not buf:
                            break
                        rf.write(buf)
                        cb(len(buf))
                    if fin:
                        fin()
            else:
                c = self.client
                c.voidcmd("TYPE I")
                try:
                    with c.transfercmd("STOR " + remote, offset or None) as conn:
                        self.data_conn = conn
                        while True:
                            buf = fh.read(BLOCK)
                            if not buf:
                                break
                            conn.sendall(buf)
                            cb(len(buf))
                        if isinstance(conn, ssl.SSLSocket):
                            conn.unwrap()
                        if fin:
                            fin()
                finally:
                    self.data_conn = None
                c.voidresp()
        self.last = time.time()


# ---- sesi untuk menjelajah folder remote (satu koneksi per situs, dipakai ulang)
BROWSE = {}
_BLOCKS = {}
_BLOCKS_LOCK = threading.Lock()


def _blk(pid):
    with _BLOCKS_LOCK:
        return _BLOCKS.setdefault(pid, threading.RLock())


def BROWSE_DROP(pid):
    with _blk(pid):
        c = BROWSE.pop(pid, None)
    if c:
        c.close()


def _transient(e):
    ssh = (_paramiko.SSHException,) if _paramiko else ()
    return isinstance(e, (EOFError, ftplib.error_temp, ftplib.error_reply, ftplib.error_proto, socket.timeout, ssl.SSLError) + ssh) \
        or (isinstance(e, OSError) and not isinstance(e, (FileNotFoundError, PermissionError)))


def _err_text(e):
    return (str(e) or e.__class__.__name__)[:300]


def with_browse(pid, fn):
    profile = find_profile(pid)
    with _blk(profile["id"]):
        for attempt in (1, 2):
            c = BROWSE.get(profile["id"])
            if c is not None and (c.profile != profile or (time.time() - c.last > 5 and not c.alive())):
                c.close()
                c = None
            try:
                if c is None:
                    ftp_log("Menghubungkan ke %s (%s)…" % (profile["host"], profile["protocol"].upper()))
                    c = RemoteConn(profile)
                    BROWSE[profile["id"]] = c
                    ftp_log("Terhubung ke %s sebagai %s." % (profile["host"], profile["username"]))
                c.last = time.time()
                return fn(c)
            except ApiError:
                raise
            except FileNotFoundError as e:
                raise ApiError(404, "Tidak ditemukan di server: %s" % _err_text(e))
            except PermissionError as e:
                raise ApiError(403, "Ditolak server: %s" % _err_text(e))
            except ftplib.error_perm as e:
                raise ApiError(400, "Ditolak server: %s" % _err_text(e))
            except Exception as e:
                if getattr(e, "permanent", False) or (_paramiko and isinstance(e, _paramiko.AuthenticationException)):
                    BROWSE.pop(profile["id"], None)
                    raise ApiError(400, _err_text(e))
                if not _transient(e):
                    raise ApiError(500, _err_text(e))
                if c is not None:
                    c.close()
                BROWSE.pop(profile["id"], None)
                if attempt == 2:
                    ftp_log("Koneksi gagal: %s" % _err_text(e), "err")
                    raise ApiError(502, "Koneksi ke server gagal: %s" % _err_text(e))


def remote_test(profile):
    c = RemoteConn(profile)
    try:
        where = profile.get("remote_dir") or c.home
        c.listdir(c.abs(where))
        return {"ok": True, "message": "Koneksi berhasil. Folder: %s" % c.abs(where)}
    except ftplib.error_perm as e:
        raise ApiError(400, "Login berhasil, tapi folder tujuan ditolak: %s" % _err_text(e))
    finally:
        c.close()


# ---- API profil & penjelajah remote
def api_remote_profiles(q, b):
    act = b.get("action")
    if act == "save":
        saved = save_remote_profile(b)
        return {"ok": True, "profile": saved, "profiles": [public_profile(x) for x in get_remote_profiles()]}
    if act == "delete":
        pid = str(b.get("id", ""))
        store.put("remote_profiles", [x for x in get_remote_profiles() if x.get("id") != pid])
        BROWSE_DROP(pid)
        return {"ok": True, "profiles": [public_profile(x) for x in get_remote_profiles()]}
    if act == "test":
        pid = str(b.get("id", ""))
        profile = next((x for x in get_remote_profiles() if x.get("id") == pid), None)
        if not profile:
            profile = save_remote_profile(b)
        try:
            return remote_test(profile)
        except ApiError:
            raise
        except Exception as e:
            if getattr(e, "permanent", False) or _transient(e) or isinstance(e, ftplib.Error) \
                    or (_paramiko and isinstance(e, _paramiko.SSHException)):
                raise ApiError(400, "Koneksi gagal: %s" % _err_text(e))
            raise
    return {"profiles": [public_profile(x) for x in get_remote_profiles()]}


def api_remote_status(q, b):
    return {"profiles": [public_profile(x) for x in get_remote_profiles()]}


def api_ftp_list(q, b):
    pid = q.get("profile", [""])[0]
    path = q.get("path", [""])[0]
    profile = find_profile(pid)

    def go(c):
        p = c.abs(path or profile.get("remote_dir") or "")
        items = c.listdir(p)
        items.sort(key=lambda x: (not x["dir"], x["name"].lower()))
        return {"path": p, "items": items, "home": c.home}
    return with_browse(pid, go)


def api_ftp_op(q, b):
    pid = str(b.get("profile", ""))
    act = b.get("action")
    if act == "disconnect":
        BROWSE_DROP(pid)
        ftp_log("Koneksi penjelajah ditutup.")
        return {"ok": True}
    find_profile(pid)
    if act == "mkdir":
        name = valid_name(b.get("name"))

        def go(c):
            p = posixpath.join(c.abs(b.get("path")), name)
            c.mkdir(p)
            ftp_log("Folder dibuat: %s" % p)
            return {"ok": True}
        return with_browse(pid, go)
    if act == "rename":
        name = valid_name(b.get("name"))

        def go(c):
            src = c.abs(b.get("path"))
            dst = posixpath.join(posixpath.dirname(src), name)
            if any(x["name"] == name for x in c.listdir(posixpath.dirname(src) or "/")):
                raise ApiError(409, "Nama sudah dipakai di server.")
            c.rename(src, dst)
            ftp_log("Diganti nama: %s -> %s" % (src, name))
            return {"ok": True}
        return with_browse(pid, go)
    if act == "delete":
        items = b.get("items") or []
        if not isinstance(items, list) or not items or len(items) > 500:
            raise ApiError(400, "Pilih 1 sampai 500 item.")

        def go(c):
            n = 0
            errs = []
            for it in items:
                p = c.abs(str(it.get("path", "")))
                if p in ("", "/", c.home):
                    errs.append("Folder utama tidak boleh dihapus.")
                    continue
                try:
                    if it.get("dir"):
                        c.rmtree(p)
                    else:
                        c.remove(p)
                    n += 1
                    ftp_log("Dihapus di server: %s" % p, "warn")
                except (OSError, ftplib.error_perm, PermanentError) as e:
                    errs.append("%s: %s" % (posixpath.basename(p), _err_text(e)))
            return {"deleted": n, "errors": errs}
        return with_browse(pid, go)
    raise ApiError(400, "Aksi tidak dikenal.")


# ---- antrean transfer
def _is_permanent(e):
    if getattr(e, "permanent", False) or isinstance(e, (PermanentError, ApiError, ftplib.error_perm)):
        return True
    if isinstance(e, (PermissionError, FileNotFoundError, IsADirectoryError, NotADirectoryError)):
        return True
    if isinstance(e, OSError) and e.errno in (errno.ENOSPC, errno.EDQUOT, errno.EACCES, errno.EPERM, errno.ENOENT):
        return True
    if _paramiko and isinstance(e, _paramiko.AuthenticationException):
        return True
    return False


def _finish(it, status, error="", note=None):
    with TQ_COND:
        it["status"] = status
        it["error"] = error
        if note is not None:
            it["note"] = note
        it["speed"] = 0
        it["finished"] = time.time()
        it["_conn"] = None


def _upload(conn, it, ap, size, force_resume):
    base = conn.abs(it["remote_dir"])
    remote = posixpath.join(base, it["name"])
    conn.mkdirs(posixpath.dirname(remote))
    policy = "resume" if force_resume else TQ["policy"]
    rsize = conn.size(remote)
    offset = 0
    note = ""
    if rsize is not None:
        if policy == "skip":
            ftp_log("Dilewati (sudah ada): %s" % remote)
            return _finish(it, "skipped", note="Sudah ada di server")
        if policy == "rename":
            root, ext = posixpath.splitext(remote)
            for n in range(1, 500):
                cand = "%s (%d)%s" % (root, n, ext)
                if conn.size(cand) is None:
                    remote = cand
                    break
            else:
                raise PermanentError("Tidak menemukan nama bebas di server.")
            note = "Disimpan sebagai " + posixpath.basename(remote)
        elif policy == "resume":
            if rsize == size:
                store.mark_remote_upload(it["local"], it["profile_id"])
                ftp_log("Sudah lengkap di server (ukuran sama): %s" % remote)
                it["sent"] = size
                return _finish(it, "done", note="Sudah lengkap di server (ukuran sama)")
            if 0 < rsize < size:
                offset = rsize
                note = "Dilanjutkan dari %d byte" % rsize
    it["sent"] = offset
    ftp_log("Mengunggah %s (%s) ke %s" % (it["name"], _fmt_bytes(size), remote) + (" [lanjut]" if offset else ""))
    t0 = time.time()
    mark = [t0, offset]

    def cb(n):
        it["sent"] += n
        if it["cancel"]:
            raise TransferCancelled()
        now = time.time()
        if now - mark[0] >= 0.4:
            it["speed"] = (it["sent"] - mark[1]) / (now - mark[0])
            mark[0], mark[1] = now, it["sent"]

    conn.store(ap, remote, offset, cb, fin=lambda: it.__setitem__("note", "Menunggu konfirmasi server"))
    final = conn.size(remote)
    if final is not None and final != size:
        raise IOError("Ukuran di server (%d) tidak sama dengan file lokal (%d)." % (final, size))
    it["sent"] = size
    store.mark_remote_upload(it["local"], it["profile_id"])
    dt = max(0.001, time.time() - t0)
    ftp_log("Selesai: %s (%s/dtk)" % (it["name"], _fmt_bytes((size - offset) / dt)))
    _finish(it, "done", note=note + ("" if final is not None else " (ukuran akhir tidak bisa diverifikasi)").strip())


def _fmt_bytes(n):
    n = float(n)
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024 or u == "GB":
            return ("%.0f %s" % (n, u)) if u == "B" else ("%.1f %s" % (n, u))
        n /= 1024


def _drop(conns, pid):
    c = conns.pop(pid, None)
    if c:
        c.close()


def _sleep_cancelable(it, secs):
    end = time.time() + secs
    while time.time() < end:
        if it["cancel"]:
            return
        time.sleep(0.25)


def _run_item(it, conns):
    pid = it["profile_id"]
    profile = next((x for x in get_remote_profiles() if x.get("id") == pid), None)
    if not profile:
        return _finish(it, "failed", "Profil situs sudah dihapus.")
    try:
        _rel, ap = abs_of(it["local"])
        if not os.path.isfile(ap):
            raise PermanentError("File lokal tidak ditemukan.")
        size = os.path.getsize(ap)
    except (ApiError, PermanentError, OSError) as e:
        return _finish(it, "failed", e.msg if isinstance(e, ApiError) else _err_text(e))
    it["size"] = size
    for attempt in range(1, 4):
        it["attempts"] = attempt
        if it["cancel"]:
            return _finish(it, "cancelled", "Dibatalkan.")
        conn = conns.get(pid)
        try:
            if conn is not None and (conn.profile != profile or (time.time() - conn.last > 3 and not conn.alive())):
                _drop(conns, pid)
                conn = None
            if conn is None:
                ftp_log("Menghubungkan ke %s (%s)…" % (profile["host"], profile["protocol"].upper()))
                conn = RemoteConn(profile)
                conns[pid] = conn
                ftp_log("Terhubung ke %s sebagai %s." % (profile["host"], profile["username"]))
            it["_conn"] = conn
            return _upload(conn, it, ap, size, force_resume=attempt > 1)
        except TransferCancelled:
            _drop(conns, pid)
            ftp_log("Dibatalkan: %s" % it["name"], "warn")
            return _finish(it, "cancelled", "Dibatalkan.")
        except Exception as e:
            _drop(conns, pid)
            if it["cancel"]:
                ftp_log("Dibatalkan: %s" % it["name"], "warn")
                return _finish(it, "cancelled", "Dibatalkan.")
            msg = e.msg if isinstance(e, ApiError) else _err_text(e)
            if _is_permanent(e) or attempt == 3:
                ftp_log("Gagal: %s: %s" % (it["name"], msg), "err")
                return _finish(it, "failed", msg)
            ftp_log("Koneksi bermasalah (%s). Mencoba lagi %d dari 2…" % (msg, attempt), "warn")
            it["note"] = "Mencoba lagi (%d)" % attempt
            _sleep_cancelable(it, 2 * attempt)


def _tq_worker():
    conns = {}
    idle = time.time()
    while True:
        item = None
        with TQ_COND:
            if not TQ["paused"] and TQ["running"] < TQ["workers"]:
                item = next((i for i in TQ["items"] if i["status"] == "queued"), None)
                if item:
                    item.update(status="uploading", started=time.time(), speed=0, error="", cancel=False)
                    TQ["running"] += 1
            if item is None:
                TQ_COND.wait(timeout=2.0)
        if item is None:
            if conns and time.time() - idle > 25:
                for c in list(conns.values()):
                    c.close()
                conns.clear()
            continue
        try:
            _run_item(item, conns)
        except Exception as exc:  # pragma: no cover
            traceback.print_exc()
            _drop(conns, item["profile_id"])
            _finish(item, "failed", _err_text(exc))
        finally:
            with TQ_COND:
                TQ["running"] -= 1
                TQ_COND.notify_all()
            idle = time.time()


def _tq_ensure_threads():
    with TQ_COND:
        if TQ["started"]:
            return
        TQ["started"] = True
    for i in range(MAX_WORKERS):
        threading.Thread(target=_tq_worker, daemon=True, name="ftp-worker-%d" % i).start()


def api_ftp_enqueue(q, b):
    profile = find_profile(b.get("profile", ""))
    remote_dir = str(b.get("remote_dir") or profile.get("remote_dir") or "").strip()[:500]
    paths = b.get("paths") or []
    if not isinstance(paths, list) or not paths or len(paths) > 5000:
        raise ApiError(400, "Pilih 1 sampai 5000 file atau folder.")
    jobs = []
    for p in paths:
        rel, ap = abs_of(str(p))
        if rel == "":
            continue
        if os.path.isfile(ap):
            jobs.append((rel, os.path.basename(ap)))
        elif os.path.isdir(ap):
            parent = os.path.dirname(ap)
            for dp, dn, fn in os.walk(ap):
                dn[:] = sorted(d for d in dn if not d.startswith("."))
                for f in sorted(fn):
                    if f.startswith("."):
                        continue
                    full = os.path.join(dp, f)
                    jobs.append((os.path.relpath(full, STATE["root"]).replace(os.sep, "/"),
                                 os.path.relpath(full, parent).replace(os.sep, "/")))
                    if len(jobs) > 20000:
                        raise ApiError(400, "Terlalu banyak file (maksimal 20.000 sekali kirim).")
    added = skipped = 0
    with TQ_COND:
        have = {(i["profile_id"], i["local"], i["remote_dir"]) for i in TQ["items"] if i["status"] in ("queued", "uploading")}
        for rel, name in jobs:
            key = (profile["id"], rel, remote_dir)
            if key in have:
                skipped += 1
                continue
            have.add(key)
            TQ["seq"] += 1
            TQ["items"].append({"id": TQ["seq"], "profile_id": profile["id"], "profile": profile["name"],
                                "local": rel, "name": name, "remote_dir": remote_dir, "size": 0, "sent": 0,
                                "speed": 0, "status": "queued", "error": "", "note": "", "attempts": 0,
                                "cancel": False, "started": 0, "finished": 0, "_conn": None})
            added += 1
        if len(TQ["items"]) > 25000:
            keep = [i for i in TQ["items"] if i["status"] in ("queued", "uploading", "failed")]
            TQ["items"] = keep
        TQ_COND.notify_all()
    if added:
        ftp_log("%d file masuk antrean ke %s (%s)." % (added, profile["name"], remote_dir or "folder default"))
    _tq_ensure_threads()
    return {"added": added, "skipped": skipped}


_TABS = {"queue": ("queued", "uploading"), "failed": ("failed", "cancelled"), "done": ("done", "skipped")}


def api_ftp_queue(q, b):
    tab = q.get("tab", ["queue"])[0]
    try:
        limit = max(1, min(500, int(q.get("limit", ["200"])[0])))
    except ValueError:
        limit = 200
    with TQ_COND:
        counts = {k: 0 for k in _TABS}
        speed = 0.0
        left = 0
        for i in TQ["items"]:
            for k, sts in _TABS.items():
                if i["status"] in sts:
                    counts[k] += 1
            if i["status"] == "uploading":
                speed += i["speed"]
            if i["status"] in ("queued", "uploading"):
                left += max(0, (i["size"] or 0) - i["sent"])
        items = []
        if tab in _TABS:
            sel = [i for i in TQ["items"] if i["status"] in _TABS[tab]]
            if tab == "queue":
                sel.sort(key=lambda x: (x["status"] != "uploading", x["id"]))
            else:
                sel.sort(key=lambda x: -x["finished"])
            items = [{k: i[k] for k in ("id", "profile", "name", "remote_dir", "size", "sent", "speed", "status",
                                        "error", "note", "attempts")} for i in sel[:limit]]
        return {"counts": counts, "items": items, "speed": speed, "left": left, "workers": TQ["workers"],
                "paused": TQ["paused"], "policy": TQ["policy"], "running": TQ["running"]}


def api_ftp_queue_action(q, b):
    act = b.get("action")
    try:
        ids = {int(x) for x in (b.get("ids") or [])}
    except (TypeError, ValueError):
        raise ApiError(400, "ID tidak valid.")
    with TQ_COND:
        items = TQ["items"]
        if act in ("cancel", "cancel_all"):
            for i in items:
                if act == "cancel_all" or i["id"] in ids:
                    if i["status"] == "queued":
                        i.update(status="cancelled", error="Dibatalkan.", finished=time.time())
                    elif i["status"] == "uploading":
                        i["cancel"] = True
                        if i.get("_conn") is not None:
                            i["_conn"].abort()
        elif act in ("retry", "retry_failed"):
            for i in items:
                if i["status"] in ("failed", "cancelled") and (act == "retry_failed" or i["id"] in ids):
                    i.update(status="queued", error="", note="", sent=0, speed=0, attempts=0, cancel=False)
        elif act == "remove":
            TQ["items"] = [i for i in items if not (i["id"] in ids and i["status"] != "uploading")]
        elif act == "clear_done":
            TQ["items"] = [i for i in items if i["status"] not in ("done", "skipped")]
        elif act == "pause":
            TQ["paused"] = True
            ftp_log("Antrean dijeda (transfer yang berjalan diselesaikan dulu).")
        elif act == "resume":
            TQ["paused"] = False
            ftp_log("Antrean dilanjutkan.")
        elif act == "settings":
            if "workers" in b:
                try:
                    TQ["workers"] = max(1, min(MAX_WORKERS, int(b["workers"])))
                except (TypeError, ValueError):
                    pass
            if b.get("policy") in POLICIES:
                TQ["policy"] = b["policy"]
        else:
            raise ApiError(400, "Aksi tidak dikenal.")
        TQ_COND.notify_all()
    if act in ("retry", "retry_failed", "resume"):
        _tq_ensure_threads()
    return {"ok": True}


def api_ftp_log(q, b):
    try:
        since = int(q.get("since", ["0"])[0])
    except ValueError:
        since = 0
    with TQ_COND:
        lines = [x for x in FTP_LOG if x["n"] > since][-400:]
        return {"lines": lines, "last": FTP_LOG_SEQ[0]}



GET_ROUTES = {
    "/api/config": api_config,
    "/api/list": api_list,
    "/api/storage": api_storage,
    "/api/reclaimable": api_reclaimable,
    "/api/info": api_info,
    "/api/remote-profiles": api_remote_status,
    "/api/ftp/list": api_ftp_list,
    "/api/ftp/queue": api_ftp_queue,
    "/api/ftp/log": api_ftp_log,
}
POST_ROUTES = {
    "/api/mark": api_mark,
    "/api/move": api_move,
    "/api/copy": api_copy,
    "/api/delete": api_delete,
    "/api/mkdir": api_mkdir,
    "/api/rename": api_rename,
    "/api/settings": api_settings,
    "/api/rescan": api_rescan,
    "/api/remote-profiles": api_remote_profiles,
    "/api/ftp/op": api_ftp_op,
    "/api/ftp/enqueue": api_ftp_enqueue,
    "/api/ftp/queue-action": api_ftp_queue_action,
}


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------
# Autentikasi: login dengan password + cookie sesi bertanda tangan
# --------------------------------------------------------------------------
SESSION_TTL = 14 * 24 * 3600
PBKDF2_ITER = 310_000
MIN_PASSWORD = 10
AUTH_FAILS = {}
AUTH_LOCK = threading.Lock()


def auth_enabled():
    return store.get("auth") is not None


def set_password(pw):
    if len(pw) < MIN_PASSWORD:
        raise ValueError("Password minimal %d karakter." % MIN_PASSWORD)
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, PBKDF2_ITER)
    store.put("auth", {"salt": salt.hex(), "hash": dk.hex(), "iter": PBKDF2_ITER})
    # Mengganti rahasia sesi membuat semua login lama otomatis tidak berlaku.
    store.put("session_secret", secrets.token_hex(32))


def check_password(pw):
    rec = store.get("auth")
    if not rec:
        return False
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), bytes.fromhex(rec["salt"]), int(rec["iter"]))
    return hmac.compare_digest(dk.hex(), rec["hash"])


def _session_secret():
    sec = store.get("session_secret")
    if not sec:
        sec = secrets.token_hex(32)
        store.put("session_secret", sec)
    return sec.encode()


def make_token():
    msg = "%d.%s" % (int(time.time()) + SESSION_TTL, secrets.token_hex(8))
    return msg + "." + hmac.new(_session_secret(), msg.encode(), hashlib.sha256).hexdigest()


def token_ok(tok):
    try:
        exp, nonce, sig = tok.split(".")
        want = hmac.new(_session_secret(), ("%s.%s" % (exp, nonce)).encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(sig, want) and int(exp) > time.time()
    except Exception:
        return False


# --------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "Stockroom"
    protocol_version = "HTTP/1.1"
    timeout = 120

    def setup(self):
        ctx = STATE.get("tls_ctx")
        if ctx:
            # Jabat tangan TLS dilakukan di thread permintaan agar klien lambat tidak menahan server.
            self.request.settimeout(20)
            self.request = ctx.wrap_socket(self.request, server_side=True)
        super().setup()

    def _sec_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")

    def log_message(self, *a):
        pass

    # --- helpers
    def _send(self, status, body, ctype, extra=None):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self._sec_headers()
        self.send_header("Cache-Control", "no-store")
        if ctype.startswith("text/html"):
            self.send_header("Content-Security-Policy",
                             "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; "
                             "style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; "
                             "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, status=200):
        self._send(status, json.dumps(obj).encode("utf-8"), "application/json; charset=utf-8")

    def _redirect(self, loc):
        self.send_response(302)
        self.send_header("Location", loc)
        self.send_header("Content-Length", "0")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def _cookie(self, value, max_age):
        return "sr_session=%s; Path=/; Max-Age=%d; HttpOnly; SameSite=Strict%s" % (
            value, max_age, "; Secure" if STATE["tls"] else "")

    def _authed(self):
        if not auth_enabled():
            return True
        for part in self.headers.get("Cookie", "").split(";"):
            k, _, v = part.strip().partition("=")
            if k == "sr_session":
                return token_ok(v)
        return False

    def _login(self, body):
        ip = self.client_address[0]
        now = time.time()
        with AUTH_LOCK:
            for k in [k for k, v in AUTH_FAILS.items() if v["until"] < now - 3600 and v["last"] < now - 3600]:
                AUTH_FAILS.pop(k, None)
            rec = AUTH_FAILS.get(ip)
            if rec and rec["until"] > now:
                raise ApiError(429, "Terlalu banyak percobaan gagal. Coba lagi dalam %d menit." % (int((rec["until"] - now) / 60) + 1))
        if not auth_enabled():
            return self._json({"ok": True})
        if check_password(str(body.get("password", ""))[:256]):
            with AUTH_LOCK:
                AUTH_FAILS.pop(ip, None)
            return self._send(200, b'{"ok": true}', "application/json; charset=utf-8",
                              {"Set-Cookie": self._cookie(make_token(), SESSION_TTL)})
        time.sleep(0.8)
        with AUTH_LOCK:
            rec = AUTH_FAILS.setdefault(ip, {"n": 0, "until": 0, "last": 0})
            rec["n"] += 1
            rec["last"] = time.time()
            if rec["n"] >= 5:
                rec["until"] = time.time() + 300 * min(rec["n"] - 4, 12)
        raise ApiError(401, "Password salah.")

    def _host_ok(self):
        if STATE["any_host"]:
            return True
        host = self.headers.get("Host", "").rsplit(":", 1)[0].strip("[]").lower()
        return host in ("localhost", "127.0.0.1", "::1")

    def _send_file(self, path, ctype=None, cache=False):
        try:
            size = os.path.getsize(path)
        except OSError:
            raise ApiError(404, "File tidak ditemukan.")
        ctype = ctype or mimetypes.guess_type(path)[0] or "application/octet-stream"
        start, end, status = 0, size - 1, 200
        rng = self.headers.get("Range")
        if rng and rng.startswith("bytes=") and size > 0:
            try:
                a, bb = rng[6:].split(",")[0].split("-", 1)
                if a == "":
                    start = max(0, size - int(bb))
                else:
                    start = int(a)
                    end = int(bb) if bb else size - 1
                end = min(end, size - 1)
                if start > end:
                    raise ValueError
                status = 206
            except ValueError:
                self.send_response(416)
                self.send_header("Content-Range", "bytes */%d" % size)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
        length = end - start + 1 if size else 0
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        if getattr(self, "_download_name", None):
            name = self._download_name
            fallback = re.sub(r'[^A-Za-z0-9._ -]', '_', name).strip() or "download"
            self.send_header("Content-Disposition", "attachment; filename=\"%s\"; filename*=UTF-8''%s" % (fallback.replace('\\', '_').replace('\"', '_'), quote(name)))
        self.send_header("Content-Length", str(length))
        self.send_header("Accept-Ranges", "bytes")
        self._sec_headers()
        self.send_header("Cache-Control", "private, max-age=86400" if cache else "no-store")
        if ctype.startswith("image/svg"):
            self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; img-src data:; sandbox")
        if status == 206:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        self.end_headers()
        with open(path, "rb") as f:
            f.seek(start)
            left = length
            while left > 0:
                chunk = f.read(min(1 << 16, left))
                if not chunk:
                    break
                self.wfile.write(chunk)
                left -= len(chunk)

    def _serve_thumb(self, q, preview):
        rel, ap = abs_of(q.get("path", [""])[0])
        if not os.path.isfile(ap):
            raise ApiError(404, "File tidak ditemukan.")
        ext = os.path.splitext(ap)[1].lower().lstrip(".")
        if preview:
            w = 1800
            if ext in ("svg", "gif"):
                return self._send_file(ap)
        else:
            try:
                w = max(64, min(1200, int(q.get("w", ["320"])[0])))
            except ValueError:
                w = 320
            if ext == "svg":
                return self._send_file(ap, cache=True)
        t = make_thumb(ap, w)
        if t:
            return self._send_file(str(t), "image/png" if str(t).endswith(".png") else "image/jpeg", cache=True)
        if ext in NATIVE_IMG:
            return self._send_file(ap, cache=True)
        raise ApiError(404, "Tidak ada pratinjau.")

    # --- dispatch
    def do_GET(self):
        self._dispatch("GET")

    def do_PUT(self):
        temp_path = None
        try:
            if not self._host_ok():
                raise ApiError(403, "Host tidak diizinkan.")
            if not self._authed():
                return self._json({"error": "Sesi berakhir. Silakan login lagi.", "login": True}, 401)
            if self.headers.get("X-Requested-With") != "stockroom":
                raise ApiError(403, "Permintaan ditolak.")
            u = urlparse(self.path)
            if u.path != "/api/upload":
                raise ApiError(404, "Tidak ditemukan.")
            q = parse_qs(u.query)
            _rel, dest = abs_of(q.get("path", [""])[0])
            if not os.path.isdir(dest):
                raise ApiError(404, "Folder tujuan tidak ditemukan.")
            try:
                size = int(self.headers.get("Content-Length", ""))
            except ValueError:
                raise ApiError(411, "Ukuran file tidak diketahui.")
            if size <= 0:
                raise ApiError(400, "File kosong atau ukuran tidak valid.")
            if size > 100 * 1024 * 1024 * 1024:
                raise ApiError(413, "Ukuran file melebihi batas 100 GB.")
            name = unquote(self.headers.get("X-File-Name", "")).strip()
            name = valid_name(name)
            temp_path = os.path.join(dest, ".%s.uploading" % uuid.uuid4().hex)
            remaining = size
            with open(temp_path, "xb") as out:
                while remaining:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ApiError(400, "Upload terputus sebelum selesai.")
                    out.write(chunk)
                    remaining -= len(chunk)
                out.flush()
                os.fsync(out.fileno())
            final_name = unique_dest(dest, name)
            os.replace(temp_path, os.path.join(dest, final_name))
            temp_path = None
            scanner.start()
            self._json({"ok": True, "name": final_name, "size": size})
        except ApiError as e:
            if temp_path and os.path.exists(temp_path):
                os.remove(temp_path)
            try:
                self._json({"error": e.msg}, e.status)
            except OSError:
                pass
        except OSError as e:
            if temp_path and os.path.exists(temp_path):
                try: os.remove(temp_path)
                except OSError: pass
            try:
                self._json({"error": "Gagal menyimpan file: %s" % (e.strerror or e)}, 507)
            except OSError:
                pass
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            if temp_path and os.path.exists(temp_path):
                try: os.remove(temp_path)
                except OSError: pass


    def do_POST(self):
        self._dispatch("POST")

    def _dispatch(self, method):
        try:
            body = {}
            if method == "POST":
                n = int(self.headers.get("Content-Length") or 0)
                raw = self.rfile.read(n) if 0 < n <= 8_000_000 else b""
                try:
                    body = json.loads(raw.decode("utf-8")) if raw else {}
                except ValueError:
                    raise ApiError(400, "Permintaan tidak valid.")
            if not self._host_ok():
                raise ApiError(403, "Host tidak diizinkan.")
            u = urlparse(self.path)
            q = parse_qs(u.query)
            if u.path == "/login" and method == "GET":
                if self._authed() and auth_enabled():
                    return self._redirect("/")
                return self._send(200, (HERE / "static" / "login.html").read_bytes(), "text/html; charset=utf-8")
            if u.path == "/api/login" and method == "POST":
                if self.headers.get("X-Requested-With") != "stockroom":
                    raise ApiError(403, "Permintaan ditolak.")
                return self._login(body)
            if u.path == "/api/logout" and method == "POST":
                if self.headers.get("X-Requested-With") != "stockroom":
                    raise ApiError(403, "Permintaan ditolak.")
                return self._send(200, b'{"ok": true}', "application/json; charset=utf-8",
                                  {"Set-Cookie": self._cookie("", 0)})
            if not self._authed():
                if method == "GET" and u.path in ("/", "/index.html"):
                    return self._redirect("/login")
                return self._json({"error": "Perlu login.", "login": True}, 401)
            if method == "POST":
                if self.headers.get("X-Requested-With") != "stockroom":
                    raise ApiError(403, "Permintaan ditolak.")
                fn = POST_ROUTES.get(u.path)
                if not fn:
                    raise ApiError(404, "Tidak ditemukan.")
                return self._json(fn(q, body))
            if u.path in ("/", "/index.html"):
                html = (HERE / "static" / "index.html").read_bytes()
                return self._send(200, html, "text/html; charset=utf-8")
            if u.path == "/api/thumb":
                return self._serve_thumb(q, False)
            if u.path == "/api/preview":
                return self._serve_thumb(q, True)
            if u.path == "/api/file":
                rel, ap = abs_of(q.get("path", [""])[0])
                if not os.path.isfile(ap):
                    raise ApiError(404, "File tidak ditemukan.")
                self._download_name = os.path.basename(ap) if q.get("download", [""])[0] == "1" else None
                return self._send_file(ap)
            fn = GET_ROUTES.get(u.path)
            if fn:
                return self._json(fn(q, {}))
            raise ApiError(404, "Tidak ditemukan.")
        except ApiError as e:
            try:
                self._json({"error": e.msg}, e.status)
            except OSError:
                pass
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass
        except Exception as e:  # pragma: no cover
            traceback.print_exc()
            try:
                self._json({"error": "Kesalahan server: %s" % e}, 500)
            except OSError:
                pass


def port_open(host, port):
    try:
        with socket.create_connection((host, port), 0.4):
            return True
    except OSError:
        return False


class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 64

    def handle_error(self, request, client_address):
        # Jabat tangan TLS gagal, klien memutus koneksi, dan sejenisnya adalah hal biasa di internet publik.
        if issubclass(sys.exc_info()[0] or Exception, (OSError, EOFError)):
            return
        super().handle_error(request, client_address)


def read_new_password():
    pw = os.environ.get("STOCKROOM_NEW_PASSWORD")
    if pw is None:
        pw = getpass.getpass("Password baru (minimal %d karakter): " % MIN_PASSWORD)
        if pw != getpass.getpass("Ulangi password: "):
            sys.exit("Password tidak sama.")
    return pw


def main():
    ap = argparse.ArgumentParser(description="Stockroom - manajer file upload microstock")
    ap.add_argument("--root", help="folder utama yang dikelola (default: yang terakhir dipakai atau ~/Microstock)")
    ap.add_argument("--host", default="127.0.0.1", help="alamat bind (127.0.0.1 = hanya lokal, 0.0.0.0 = semua jaringan)")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--tls-cert", help="file sertifikat TLS (PEM) untuk HTTPS")
    ap.add_argument("--tls-key", help="file kunci privat TLS (PEM)")
    ap.add_argument("--set-password", action="store_true", help="atur password login lalu keluar")
    ap.add_argument("--auth-status", action="store_true", help="cetak 'set' atau 'unset' lalu keluar")
    ap.add_argument("--password", default=os.environ.get("STOCKROOM_PASSWORD"),
                    help="(lama) atur password saat start; lebih baik pakai --set-password")
    ap.add_argument("--open", action="store_true", help="buka browser otomatis")
    a = ap.parse_args()

    if a.auth_status:
        print("set" if auth_enabled() else "unset")
        sys.exit(0 if auth_enabled() else 1)
    if a.set_password:
        try:
            set_password(read_new_password())
        except ValueError as e:
            sys.exit(str(e))
        print("Password login disimpan. Semua sesi login lama otomatis keluar.")
        return
    if a.password:
        try:
            set_password(a.password)
        except ValueError as e:
            sys.exit(str(e))

    local = a.host in ("127.0.0.1", "localhost", "::1")
    if not local and not auth_enabled():
        sys.exit("Akses dari jaringan butuh password login. Jalankan dulu: python3 app.py --set-password")
    if bool(a.tls_cert) != bool(a.tls_key):
        sys.exit("--tls-cert dan --tls-key harus dipakai bersamaan.")

    scheme = "https" if a.tls_cert else "http"
    url = "%s://%s:%d/" % (scheme, "127.0.0.1" if local else a.host, a.port)
    if a.open and port_open("127.0.0.1", a.port):
        print("Stockroom sudah berjalan di", url)
        webbrowser.open(url)
        return

    root = a.root or store.get("root") or str(Path.home() / "Microstock")
    root = os.path.realpath(os.path.expanduser(root))
    os.makedirs(root, exist_ok=True)
    store.put("root", root)
    STATE.update(root=root, any_host=not local)
    if a.tls_cert:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(a.tls_cert, a.tls_key)
        STATE.update(tls_ctx=ctx, tls=True)
    scanner.start()

    srv = Server((a.host, a.port), Handler)
    print("Stockroom %s" % VERSION)
    print("  Folder utama : %s" % root)
    print("  Buka di      : %s" % url)
    print("  Keamanan     : login %s, %s" % ("aktif" if auth_enabled() else "nonaktif (hanya lokal)", "HTTPS" if a.tls_cert else "HTTP tanpa enkripsi"))
    print("  Thumbnail    : %s, video: %s" % ("Pillow" if HAS_PIL else "tanpa Pillow (lambat)", "ffmpeg" if HAS_FFMPEG else "tanpa ffmpeg"))
    if not local and not a.tls_cert:
        print("  PERINGATAN   : tanpa HTTPS, password dan data dikirim tanpa enkripsi lewat internet.")
    if a.open:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nBerhenti.")


if __name__ == "__main__":
    main()
