# Stockroom 1.4.2

Manajer file microstock untuk VPS Ubuntu/Debian. Mendukung dua panel file manager, pratinjau, penandaan marketplace, pemindahan/penyalinan, penghapusan terkontrol, upload file dari laptop ke VPS, serta pengiriman file dari VPS ke platform microstock melalui FTP/FTPS/SFTP dengan antrean dan status per file.

## Instalasi satu kali / update

Ekstrak ZIP, masuk ke folder `stockroom-ready`, lalu jalankan:

```bash
sudo bash setup.sh
```

Jika sudah login sebagai `root`, cukup:

```bash
bash setup.sh
```

Script akan:
- memasang aplikasi ke `/opt/stockroom`;
- membuat folder data `/root/Microstock` jika belum ada;
- membuat dan mengaktifkan systemd service `stockroom`;
- menguji HTTP lokal sebelum menyatakan instalasi berhasil;
- mempertahankan database tanda upload di `/root/.local/share/stockroom`.

Tidak perlu menginstall pip package. Python 3.8+ sudah cukup. Pillow dan FFmpeg hanya opsional untuk thumbnail dan metadata media.

## Mengakses dari Mac/laptop melalui SSH Tunnel

Di terminal laptop, biarkan perintah ini tetap berjalan:

```bash
ssh -N -L 8765:127.0.0.1:8765 root@IP_VPS_ANDA
```

Ganti `IP_VPS_ANDA` dengan IP VPS. Kemudian buka:

```text
http://127.0.0.1:8765
```

Jangan tutup terminal SSH selama aplikasi digunakan. Server sengaja hanya mendengarkan `127.0.0.1`, sehingga port aplikasi tidak terekspos langsung ke internet.

## Mengelola akun FTP/FTPS/SFTP

Di menu Kirim file ke platform, setiap profil akun memiliki tombol **Edit**, **Test**, dan **Hapus**. Saat mengedit, isi password boleh dikosongkan untuk mempertahankan password yang tersimpan; isi password baru hanya jika ingin menggantinya. Perubahan host, port, protokol, username, folder tujuan, dan nama akun disimpan pada profil yang sama sehingga tidak perlu membuat profil ulang.

## Mengelola service di VPS

```bash
systemctl status stockroom --no-pager
systemctl restart stockroom
systemctl stop stockroom
systemctl start stockroom
journalctl -u stockroom -f
```

## Mengubah port atau folder data

Default: port `8765`, folder `/root/Microstock`.

```bash
STOCKROOM_PORT=9000 bash setup.sh
```

Atau:

```bash
STOCKROOM_ROOT=/data/microstock bash setup.sh
```

Jalankan sebagai root. Setelah mengubah port, gunakan port yang sama pada SSH tunnel.

## Upload

Klik **Upload file** pada toolbar. Pilih satu atau beberapa file dari komputer. Upload berjalan satu per satu dan menampilkan progres tiap file. Jika nama file sudah ada, Stockroom menambahkan akhiran `(1)`, `(2)`, dan seterusnya; file lama tidak ditimpa. Batas saat ini 100 GB per file.


## Upload ke platform microstock (FTP / FTPS / SFTP)

1. Pilih file di panel Stockroom (hanya file, bukan folder).
2. Klik **Kirim ke platform**.
3. Tambahkan profil koneksi atau pilih profil yang sudah tersimpan.
4. Tambahkan setiap akun sebagai profil tersendiri. Contoh: `Shutterstock - Akun 1`, `Shutterstock - Akun 2`, dan `Adobe Stock - Akun 1`. Nama akun harus dibuat berbeda agar mudah dikenali.
5. Centang satu atau beberapa akun (termasuk beberapa akun dari platform yang sama), lalu klik **Mulai upload**.
6. Stockroom mengirim file ke setiap akun secara terpisah dan menampilkan jumlah berhasil/gagal untuk masing-masing akun. Status upload disimpan per profil akun, bukan hanya per nama platform. Dengan demikian, upload ke Shutterstock Akun 1 tidak menandai Shutterstock Akun 2 sebagai selesai.

Profil bawaan yang disediakan:
- **Shutterstock**: FTPS explicit TLS, `ftps.shutterstock.com`, port `21`; masukkan email/username dan password Contributor. Detail ini mengikuti panduan resmi Shutterstock: https://submit.shutterstock.com/help/en/articles/10617392-how-do-i-upload-content-via-ftps
- **Adobe Stock**: SFTP, port `22`; host, ID, dan password harus diambil dari menu Upload → Learn More pada Contributor Portal. SFTP hanya tersedia untuk akun yang memenuhi syarat. Detail server berbeda per akun, jadi Stockroom tidak mengisi host secara otomatis. Panduan resmi: https://helpx.adobe.com/stock/contributor/submit-your-content/submit-vectors/submit-vectors-to-adobe-stock.html
- **Custom**: FTP, FTPS, atau SFTP untuk server lain.

Untuk SFTP, Stockroom membutuhkan modul Paramiko. `setup.sh` akan mencoba memasang paket `python3-paramiko` secara opsional. Jika belum terpasang, jalankan `apt-get install -y python3-paramiko` di VPS.

**Keamanan:** kredensial profil disimpan pada database lokal Stockroom di VPS. File database dibatasi ke permission owner-only, tetapi nilai password di database belum dienkripsi. Jangan membuka Stockroom ke internet publik; gunakan SSH tunnel dan lindungi akses VPS. Untuk Shutterstock, gunakan kredensial akun Contributor yang benar dan jangan membagikannya. Transfer FTPS memakai TLS.

**Penting:** transfer file yang sukses hanya berarti file sudah sampai ke server platform. Ini tidak otomatis mengisi judul, keyword, kategori, release, atau mengirim aset untuk moderasi. Metadata dan proses submit tetap dilakukan melalui Contributor Portal sesuai aturan masing-masing platform.

### Riwayat status multi-akun

Status keberhasilan FTP/SFTP disimpan terpisah dari tanda marketplace manual yang sudah ada. Pada pratinjau file, bagian **Status per akun FTP/SFTP** menunjukkan akun mana yang sudah menerima file. Jika profil koneksi dihapus, riwayat status profil tersebut tetap ada di database, tetapi nama profilnya tidak lagi ditampilkan.

## Catatan update

Jalankan kembali `bash setup.sh` dari folder versi baru. Script menghentikan service, mengganti kode aplikasi, lalu mengaktifkannya kembali. Folder data dan database status upload tidak dihapus.

## Troubleshooting

```bash
systemctl status stockroom --no-pager
journalctl -u stockroom -n 100 --no-pager
ss -lntp | grep 8765
```

Jika port sudah digunakan proses lain, pilih port berbeda menggunakan `STOCKROOM_PORT`.

## Pemeriksaan cepat

```bash
bash check.sh
```


## Download file ke komputer

Pilih satu atau beberapa file pada panel, lalu klik **Download**. Setiap file diunduh sebagai file terpisah (tidak dibuat ZIP). Lokasi penyimpanan mengikuti pengaturan browser: biasanya folder Downloads, atau dialog Save As jika browser diatur untuk selalu menanyakan lokasi penyimpanan. Untuk Safari, atur lokasi unduhan melalui Safari > Settings > General > File download location. Untuk Chrome, aktifkan Settings > Downloads > Ask where to save each file before downloading. Folder yang dipilih langsung tidak dikompres; buka folder tersebut dan pilih file di dalamnya.


## Stockroom 1.5.2 — Drag & Drop Upload

Seret file dari Finder/Desktop langsung ke area aplikasi Stockroom. File akan diunggah ke folder yang sedang aktif menggunakan antrean paralel (maksimal 3 file bersamaan). Tombol Upload File tetap tersedia.

## Akses langsung dari internet (tanpa SSH Tunnel)

Untuk akses aman tanpa Terminal lokal, gunakan domain milik sendiri yang DNS A record-nya mengarah ke IP VPS, lalu pasang reverse proxy HTTPS (misalnya Caddy) di depan Stockroom. Jangan expose port 8765 langsung ke internet. Akses publik wajib dilindungi autentikasi dan HTTPS. Konfigurasi domain belum otomatis dipasang oleh setup.sh; siapkan domain/subdomain dan pastikan port TCP 80 dan 443 dapat diakses dari internet.
