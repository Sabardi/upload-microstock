#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stockroom - manajer file upload microstock.

Satu file, tanpa dependensi wajib (hanya Python 3.8+).
Opsional: Pillow (thumbnail cepat) dan ffmpeg/ffprobe (thumbnail & info video).
"""

import argparse
import base64
import hashlib
import hmac
import json
import mimetypes
import os
import posixpath
import re
import shutil
import socket
import ssl
import ftplib
import sqlite3
import subprocess
import sys
import threading
import time
import traceback
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse, quote

try:
    from PIL import Image, ImageOps

    Image.MAX_IMAGE_PIXELS = None
    HAS_PIL = True
except Exception:  # pragma: no cover
    HAS_PIL = False

HAS_FFMPEG = bool(shutil.which("ffmpeg"))
HAS_FFPROBE = bool(shutil.which("ffprobe"))
VERSION = "1.5.1"

HERE = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share") / "stockroom"
CACHE_DIR = Path(os.environ.get("XDG_CACHE_HOME") or Path.home() / ".cache") / "stockroom" / "thumbs"

DEFAULT_MARKETS = [
    {"name": "Shutterstock", "color": "#E5484D"},
    {"name": "Adobe Stock", "color": "#7C5CFC"},
    {"name": "Freepik", "color": "#2F80ED"},
    {"name": "Dreamstime", "color": "#2CA66B"},
    {"name": "Vecteezy", "color": "#F08A24"},
    {"name": "Depositphotos", "color": "#0FA3B1"},
    {"name": "123RF", "color": "#D6409F"},
    {"name": "Pond5", "color": "#8B7355"},
]

IMG_EXT = {"jpg", "jpeg", "png", "webp", "gif", "bmp", "tif", "tiff"}
VID_EXT = {"mp4", "mov", "m4v", "webm", "mkv", "avi", "mpg", "mpeg", "mts"}
VEC_EXT = {"svg", "eps", "ai", "pdf"}
NATIVE_IMG = {"jpg", "jpeg", "png", "webp", "gif", "bmp", "svg"}

STATE = {"root": "", "password": None, "any_host": False}


def kind_of(ext):
    if ext in VID_EXT:
        return "video"
    if ext in VEC_EXT:
        return "vector"
    if ext in IMG_EXT:
        return "image"
    return "file"


class ApiError(Exception):
    def __init__(self, status, msg):
        super().__init__(msg)
        self.status = status
        self.msg = msg


# --------------------------------------------------------------------------
# Penyimpanan tanda upload (SQLite)
# --------------------------------------------------------------------------
class Store:
    def __init__(self):
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(str(DATA_DIR), 0o700)
        except OSError:
            pass
        self.lock = threading.RLock()
        self.db = sqlite3.connect(str(DATA_DIR / "stockroom.db"), check_same_thread=False)
        self.db.executescript(
            """
            CREATE TABLE IF NOT EXISTS marks(
                path   TEXT NOT NULL,
                market TEXT NOT NULL,
                ts     INTEGER NOT NULL,
                PRIMARY KEY(path, market)
            );
            CREATE TABLE IF NOT EXISTS settings(
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS remote_marks(
                path       TEXT NOT NULL,
                profile_id TEXT NOT NULL,
                ts         INTEGER NOT NULL,
                PRIMARY KEY(path, profile_id)
            );
            """
        )
        self.db.commit()
        try:
            os.chmod(str(DATA_DIR / "stockroom.db"), 0o600)
        except OSError:
            pass

    def get(self, key, default=None):
        with self.lock:
            r = self.db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return json.loads(r[0]) if r else default

    def put(self, key, value):
        with self.lock:
            self.db.execute(
                "INSERT INTO settings(key,value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, json.dumps(value)),
            )
            self.db.commit()

    def marks_in_dir(self, rel):
        with self.lock:
            if rel:
                prefix = rel + "/"
                rows = self.db.execute(
                    "SELECT path, market FROM marks WHERE path>=? AND path<?",
                    (prefix, rel + "0"),
                ).fetchall()
            else:
                prefix = ""
                rows = self.db.execute("SELECT path, market FROM marks WHERE path NOT LIKE '%/%'").fetchall()
        out = {}
        for p, m in rows:
            name = p[len(prefix):]
            if "/" in name:
                continue
            out.setdefault(name, []).append(m)
        return out

    def all_marks(self):
        with self.lock:
            rows = self.db.execute("SELECT path, market FROM marks").fetchall()
        out = {}
        for p, m in rows:
            out.setdefault(p, set()).add(m)
        return out

    def apply(self, files, markets, action):
        now = int(time.time())
        with self.lock:
            c = self.db
            if action == "add":
                c.executemany(
                    "INSERT OR IGNORE INTO marks(path,market,ts) VALUES(?,?,?)",
                    [(f, m, now) for f in files for m in markets],
                )
            elif action == "remove":
                c.executemany(
                    "DELETE FROM marks WHERE path=? AND market=?",
                    [(f, m) for f in files for m in markets],
                )
            elif action == "clear":
                c.executemany("DELETE FROM marks WHERE path=?", [(f,) for f in files])
            c.commit()

    def remote_marks_in_dir(self, rel):
        with self.lock:
            if rel:
                prefix = rel + "/"
                rows = self.db.execute(
                    "SELECT path, profile_id FROM remote_marks WHERE path>=? AND path<?",
                    (prefix, rel + "0"),
                ).fetchall()
            else:
                prefix = ""
                rows = self.db.execute("SELECT path, profile_id FROM remote_marks WHERE path NOT LIKE '%/%'").fetchall()
        out = {}
        for path, profile_id in rows:
            name = path[len(prefix):]
            if "/" not in name:
                out.setdefault(name, []).append(profile_id)
        return out

    def mark_remote_upload(self, rel, profile_id):
        with self.lock:
            self.db.execute(
                "INSERT OR REPLACE INTO remote_marks(path,profile_id,ts) VALUES(?,?,?)",
                (rel, profile_id, int(time.time())),
            )
            self.db.commit()

    def delete_marks(self, rel):
        with self.lock:
            for table in ("marks", "remote_marks"):
                self.db.execute("DELETE FROM %s WHERE path=?" % table, (rel,))
                self.db.execute("DELETE FROM %s WHERE path>=? AND path<?" % table, (rel + "/", rel + "0"))
            self.db.commit()

    def rename_marks(self, old, new):
        with self.lock:
            c = self.db
            c.execute("DELETE FROM marks WHERE path=?", (new,))
            c.execute("DELETE FROM marks WHERE path>=? AND path<?", (new + "/", new + "0"))
            c.execute("UPDATE marks SET path=? WHERE path=?", (new, old))
            rows = c.execute(
                "SELECT path, market FROM marks WHERE path>=? AND path<?", (old + "/", old + "0")
            ).fetchall()
            c.executemany(
                "UPDATE marks SET path=? WHERE path=? AND market=?",
                [(new + p[len(old):], p, m) for p, m in rows],
            )
            c.execute("DELETE FROM remote_marks WHERE path=?", (new,))
            c.execute("DELETE FROM remote_marks WHERE path>=? AND path<?", (new + "/", new + "0"))
            c.execute("UPDATE remote_marks SET path=? WHERE path=?", (new, old))
            remote_rows = c.execute(
                "SELECT path, profile_id FROM remote_marks WHERE path>=? AND path<?", (old + "/", old + "0")
            ).fetchall()
            c.executemany(
                "UPDATE remote_marks SET path=? WHERE path=? AND profile_id=?",
                [(new + p[len(old):], p, pid) for p, pid in remote_rows],
            )
            c.commit()


store = Store()


def get_markets():
    m = store.get("markets")
    return m if m else DEFAULT_MARKETS


def get_rule():
    return store.get("done_rule", "all")


def is_done(ms, mset, rule):
    if rule == "any":
        return bool(ms & mset)
    return bool(mset) and mset <= ms


# --------------------------------------------------------------------------
# Path helper (semua path dari klien relatif terhadap root)
# --------------------------------------------------------------------------
def norm_rel(rel):
    rel = (rel or "").replace("\\", "/")
    if "\x00" in rel:
        raise ApiError(400, "Path tidak valid.")
    return posixpath.normpath("/" + rel).lstrip("/")


def abs_of(rel):
    rel = norm_rel(rel)
    root = STATE["root"]
    ap = os.path.join(root, *rel.split("/")) if rel else root
    real = os.path.realpath(ap)
    if real != root and not real.startswith(root + os.sep):
        raise ApiError(403, "Lokasi berada di luar folder utama.")
    return rel, ap


def join_rel(a, b):
    return b if not a else a + "/" + b


def valid_name(name):
    name = (name or "").strip()
    if not name or name in (".", "..") or "/" in name or "\\" in name or "\x00" in name:
        raise ApiError(400, "Nama tidak valid.")
    if len(name.encode("utf-8")) > 255:
        raise ApiError(400, "Nama terlalu panjang.")
    return name


def unique_dest(dirpath, name):
    base, ext = os.path.splitext(name)
    cand, i = name, 1
    while os.path.lexists(os.path.join(dirpath, cand)):
        cand = "%s (%d)%s" % (base, i, ext)
        i += 1
    return cand


def dir_size(path):
    total = 0
    for dp, _dn, fn in os.walk(path):
        for f in fn:
            try:
                total += os.lstat(os.path.join(dp, f)).st_size
            except OSError:
                pass
    return total


def expand_files(rel, ap):
    if os.path.isdir(ap) and not os.path.islink(ap):
        out = []
        for dp, dn, fn in os.walk(ap):
            dn[:] = [d for d in dn if not d.startswith(".")]
            for f in fn:
                if f.startswith("."):
                    continue
                out.append(os.path.relpath(os.path.join(dp, f), STATE["root"]).replace(os.sep, "/"))
        return out
    return [rel]


# --------------------------------------------------------------------------
# Pemindai library (hitung total, yang sudah terupload, dll.) di latar belakang
# --------------------------------------------------------------------------
class Scanner:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.pending = False
        self.result = None

    def start(self):
        with self.lock:
            if self.running:
                self.pending = True
                return
            self.running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while True:
            try:
                self.result = self._scan()
            except Exception:
                traceback.print_exc()
            with self.lock:
                if self.pending:
                    self.pending = False
                    continue
                self.running = False
                return

    def _scan(self):
        root = STATE["root"]
        marks = store.all_marks()
        files = size = 0
        marked = []
        for dp, dn, fn in os.walk(root):
            dn[:] = [d for d in dn if not d.startswith(".")]
            for f in fn:
                if f.startswith("."):
                    continue
                ap = os.path.join(dp, f)
                try:
                    st = os.stat(ap)
                except OSError:
                    continue
                rel = os.path.relpath(ap, root).replace(os.sep, "/")
                files += 1
                size += st.st_size
                ms = marks.get(rel)
                if ms:
                    marked.append((rel, st.st_size, int(st.st_mtime), ms))
        return {"root": root, "files": files, "bytes": size, "marked": marked, "at": time.time()}


scanner = Scanner()


def summarize(res, rule):
    mset = {m["name"] for m in get_markets()}
    done = []
    partial = 0
    for rel, sz, mt, ms in res["marked"]:
        if is_done(ms, mset, rule):
            done.append((rel, sz, mt, ms))
        else:
            partial += 1
    return done, partial


# --------------------------------------------------------------------------
# Thumbnail
# --------------------------------------------------------------------------
THUMB_SEM = threading.Semaphore(3)


def make_thumb(ap, w):
    st = os.stat(ap)
    key = hashlib.sha1(("%s|%d|%d|%d" % (ap, st.st_size, st.st_mtime_ns, w)).encode()).hexdigest()
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    for ext in ("jpg", "png"):
        c = CACHE_DIR / ("%s.%s" % (key, ext))
        if c.exists():
            return c
    ext = os.path.splitext(ap)[1].lower().lstrip(".")
    k = kind_of(ext)
    with THUMB_SEM:
        if k == "video":
            if not HAS_FFMPEG:
                return None
            out = CACHE_DIR / (key + ".jpg")
            tmp = CACHE_DIR / (key + ".part.jpg")
            for ss in ("1", "0"):
                try:
                    r = subprocess.run(
                        ["ffmpeg", "-v", "error", "-y", "-ss", ss, "-i", ap, "-frames:v", "1",
                         "-vf", "scale=%d:-2" % w, "-q:v", "5", str(tmp)],
                        capture_output=True, timeout=40,
                    )
                except (subprocess.TimeoutExpired, OSError):
                    return None
                if r.returncode == 0 and tmp.exists() and tmp.stat().st_size > 0:
                    os.replace(tmp, out)
                    return out
            return None
        if HAS_PIL and ext != "svg":
            try:
                im = Image.open(ap)
                if im.format == "JPEG":
                    im.draft("RGB", (w * 2, w * 2))
                im = ImageOps.exif_transpose(im)
                im.thumbnail((w, w))
                alpha = im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info)
                if alpha:
                    out = CACHE_DIR / (key + ".png")
                    tmp = CACHE_DIR / (key + ".part.png")
                    im.convert("RGBA").save(tmp, "PNG")
                else:
                    out = CACHE_DIR / (key + ".jpg")
                    tmp = CACHE_DIR / (key + ".part.jpg")
                    im.convert("RGB").save(tmp, "JPEG", quality=82)
                os.replace(tmp, out)
                return out
            except Exception:
                return None
    return None


# --------------------------------------------------------------------------
# API
# --------------------------------------------------------------------------
def api_config(q, b):
    return {
        "root": STATE["root"],
        "markets": get_markets(),
        "remote_profiles": [public_profile(x) for x in get_remote_profiles()],
        "done_rule": get_rule(),
        "warn_pct": store.get("warn_pct", 10),
        "has_pillow": HAS_PIL,
        "has_ffmpeg": HAS_FFMPEG,
        "auth": bool(STATE["password"]),
        "version": VERSION,
    }


def api_list(q, b):
    rel, ap = abs_of(q.get("path", [""])[0])
    if not os.path.isdir(ap):
        raise ApiError(404, "Folder tidak ditemukan.")
    marks = store.marks_in_dir(rel)
    remote_marks = store.remote_marks_in_dir(rel)
    items = []
    try:
        entries = list(os.scandir(ap))
    except OSError as e:
        raise ApiError(403, "Folder tidak bisa dibuka: %s" % (e.strerror or e))
    for e in entries:
        if e.name.startswith("."):
            continue
        try:
            is_dir = e.is_dir()
            st = e.stat()
        except OSError:
            continue
        if is_dir:
            n = 0
            try:
                with os.scandir(e.path) as sub:
                    for s in sub:
                        if not s.name.startswith("."):
                            n += 1
            except OSError:
                pass
            items.append({"name": e.name, "dir": True, "mtime": int(st.st_mtime), "count": n})
        else:
            ext = os.path.splitext(e.name)[1].lower().lstrip(".")
            items.append({
                "name": e.name, "dir": False, "size": st.st_size, "mtime": int(st.st_mtime),
                "ext": ext, "kind": kind_of(ext), "marks": sorted(marks.get(e.name, [])),
                "account_marks": sorted(remote_marks.get(e.name, [])),
            })
    return {"path": rel, "items": items}


def api_storage(q, b):
    du = shutil.disk_usage(STATE["root"])
    out = {"total": du.total, "used": du.total - du.free, "free": du.free, "scanning": scanner.running}
    res = scanner.result
    if res is None and not scanner.running:
        scanner.start()
        out["scanning"] = True
    if res:
        done, partial = summarize(res, get_rule())
        out.update({
            "lib_bytes": res["bytes"],
            "lib_files": res["files"],
            "reclaim_bytes": sum(x[1] for x in done),
            "reclaim_files": len(done),
            "partial_files": partial,
            "pending_files": res["files"] - len(res["marked"]),
            "scanned_at": res["at"],
        })
    return out


def api_reclaimable(q, b):
    rule = q.get("rule", [get_rule()])[0]
    if rule not in ("all", "any"):
        rule = "all"
    order = q.get("sort", ["size"])[0]
    res = scanner.result
    if res is None:
        scanner.start()
        return {"scanning": True, "items": [], "count": 0, "bytes": 0}
    done, _ = summarize(res, rule)
    if order == "old":
        done.sort(key=lambda x: x[2])
    else:
        done.sort(key=lambda x: -x[1])
    items = [{"path": r, "size": s, "mtime": m, "marks": sorted(ms)} for r, s, m, ms in done[:5000]]
    return {"scanning": scanner.running, "items": items, "count": len(done), "bytes": sum(x[1] for x in done)}


def api_info(q, b):
    rel, ap = abs_of(q.get("path", [""])[0])
    if not os.path.isfile(ap):
        raise ApiError(404, "File tidak ditemukan.")
    st = os.stat(ap)
    ext = os.path.splitext(ap)[1].lower().lstrip(".")
    info = {"name": os.path.basename(ap), "size": st.st_size, "mtime": int(st.st_mtime), "ext": ext, "kind": kind_of(ext)}
    if HAS_PIL and ext in IMG_EXT:
        try:
            with Image.open(ap) as im:
                info["w"], info["h"] = im.size
        except Exception:
            pass
    elif info["kind"] == "video" and HAS_FFPROBE:
        try:
            r = subprocess.run(
                ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                 "stream=width,height,duration", "-of", "json", ap],
                capture_output=True, timeout=10,
            )
            s = json.loads(r.stdout or b"{}").get("streams", [{}])[0]
            info["w"], info["h"] = s.get("width"), s.get("height")
            if s.get("duration"):
                info["duration"] = float(s["duration"])
        except Exception:
            pass
    return info


def api_mark(q, b):
    action = b.get("action")
    if action not in ("add", "remove", "clear"):
        raise ApiError(400, "Aksi tidak dikenal.")
    markets = [str(m)[:60] for m in (b.get("markets") or [])]
    if action != "clear" and not markets:
        raise ApiError(400, "Pilih marketplace.")
    files = []
    for p in b.get("paths") or []:
        rel, ap = abs_of(p)
        if rel == "":
            continue
        files.extend(expand_files(rel, ap))
    store.apply(files, markets, action)
    scanner.start()
    return {"ok": True, "files": len(files)}


def _transfer(b, copy):
    drel, dap = abs_of(b.get("dest", ""))
    if not os.path.isdir(dap):
        raise ApiError(404, "Folder tujuan tidak ada.")
    done = renamed = skipped = 0
    errors = []
    dreal = os.path.realpath(dap)
    for p in b.get("paths") or []:
        srel, sap = abs_of(p)
        name = os.path.basename(sap)
        if srel == "":
            errors.append("Folder utama tidak bisa dipindah.")
            continue
        sreal = os.path.realpath(sap)
        if not copy and os.path.dirname(sreal) == dreal:
            skipped += 1
            continue
        if os.path.isdir(sap) and (dreal == sreal or dreal.startswith(sreal + os.sep)):
            errors.append("%s: tidak bisa dimasukkan ke dalam dirinya sendiri." % name)
            continue
        new_name = unique_dest(dap, name)
        target = os.path.join(dap, new_name)
        try:
            if copy:
                if os.path.isdir(sap):
                    shutil.copytree(sap, target)
                else:
                    shutil.copy2(sap, target)
            else:
                shutil.move(sap, target)
                store.rename_marks(srel, join_rel(drel, new_name))
            done += 1
            if new_name != name:
                renamed += 1
        except (OSError, shutil.Error) as e:
            errors.append("%s: %s" % (name, getattr(e, "strerror", None) or e))
    scanner.start()
    return {"done": done, "renamed": renamed, "skipped": skipped, "errors": errors}


def api_move(q, b):
    return _transfer(b, False)


def api_copy(q, b):
    return _transfer(b, True)


def api_delete(q, b):
    n = freed = 0
    errors = []
    for p in b.get("paths") or []:
        rel, ap = abs_of(p)
        if rel == "":
            errors.append("Folder utama tidak bisa dihapus.")
            continue
        try:
            if os.path.isdir(ap) and not os.path.islink(ap):
                sz = dir_size(ap)
                shutil.rmtree(ap)
            else:
                sz = os.lstat(ap).st_size
                os.remove(ap)
            store.delete_marks(rel)
            n += 1
            freed += sz
        except OSError as e:
            errors.append("%s: %s" % (os.path.basename(ap), e.strerror or e))
    scanner.start()
    return {"deleted": n, "freed": freed, "errors": errors}


def api_mkdir(q, b):
    rel, ap = abs_of(b.get("path", ""))
    name = valid_name(b.get("name"))
    target = os.path.join(ap, name)
    if os.path.lexists(target):
        raise ApiError(409, "Nama sudah dipakai.")
    try:
        os.mkdir(target)
    except OSError as e:
        raise ApiError(400, e.strerror or str(e))
    return {"ok": True}


def api_rename(q, b):
    rel, ap = abs_of(b.get("path", ""))
    if rel == "":
        raise ApiError(400, "Folder utama tidak bisa diganti namanya.")
    name = valid_name(b.get("name"))
    target = os.path.join(os.path.dirname(ap), name)
    if os.path.lexists(target) and os.path.realpath(target) != os.path.realpath(ap):
        raise ApiError(409, "Nama sudah dipakai.")
    try:
        os.rename(ap, target)
    except OSError as e:
        raise ApiError(400, e.strerror or str(e))
    parent = posixpath.dirname(rel)
    store.rename_marks(rel, join_rel(parent, name))
    scanner.start()
    return {"ok": True}


def api_settings(q, b):
    if "markets" in b:
        seen, out = set(), []
        for m in b["markets"][:24]:
            name = str(m.get("name", "")).strip()[:40]
            color = str(m.get("color", ""))
            if not name or name.lower() in seen:
                continue
            if not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
                color = "#888888"
            seen.add(name.lower())
            out.append({"name": name, "color": color})
        if not out:
            raise ApiError(400, "Minimal satu marketplace.")
        store.put("markets", out)
    if b.get("done_rule") in ("all", "any"):
        store.put("done_rule", b["done_rule"])
    if "warn_pct" in b:
        try:
            store.put("warn_pct", max(1, min(50, int(b["warn_pct"]))))
        except (TypeError, ValueError):
            pass
    if b.get("root") and os.path.realpath(os.path.expanduser(b["root"])) != STATE["root"]:
        new = os.path.realpath(os.path.expanduser(b["root"]))
        if not os.path.isdir(new):
            raise ApiError(400, "Folder utama tidak ditemukan.")
        STATE["root"] = new
        store.put("root", new)
        scanner.result = None
    scanner.start()
    return api_config(q, b)


def api_rescan(q, b):
    scanner.start()
    return {"ok": True}



# --------------------------------------------------------------------------
# Remote upload profiles (FTP / FTPS / SFTP)
# --------------------------------------------------------------------------
REMOTE_JOBS = {}
REMOTE_JOBS_LOCK = threading.RLock()


def public_profile(profile):
    return {k: profile.get(k, "") for k in ("id", "name", "platform", "protocol", "host", "port", "username", "remote_dir")} 


def get_remote_profiles():
    return store.get("remote_profiles", []) or []


def save_remote_profile(data):
    name = str(data.get("name", "")).strip()[:60]
    platform = str(data.get("platform", "custom")).strip().lower()
    protocol = str(data.get("protocol", "ftps")).strip().lower()
    host = str(data.get("host", "")).strip()[:255]
    username = str(data.get("username", "")).strip()[:255]
    password = str(data.get("password", ""))
    remote_dir = str(data.get("remote_dir", "")).strip()[:500]
    if protocol not in ("ftp", "ftps", "sftp"):
        raise ApiError(400, "Protokol harus FTP, FTPS, atau SFTP.")
    if not name or not host or not username:
        raise ApiError(400, "Nama, host, dan username wajib diisi.")
    try:
        port = int(data.get("port") or (22 if protocol == "sftp" else 21))
    except (TypeError, ValueError):
        raise ApiError(400, "Port tidak valid.")
    if not 1 <= port <= 65535:
        raise ApiError(400, "Port harus antara 1 sampai 65535.")
    profiles = get_remote_profiles()
    pid = str(data.get("id") or uuid.uuid4().hex)
    old = next((x for x in profiles if x.get("id") == pid), None)
    # Saat mengedit, password kosong berarti pertahankan password lama.
    if old and not password:
        password = old.get("password", "")
    if not password:
        raise ApiError(400, "Password wajib diisi untuk profil baru.")
    profile = {"id": pid, "name": name, "platform": platform, "protocol": protocol,
               "host": host, "port": port, "username": username, "password": password,
               "remote_dir": remote_dir}
    if old:
        profiles = [profile if x.get("id") == pid else x for x in profiles]
    else:
        profiles.append(profile)
    store.put("remote_profiles", profiles[:30])
    return public_profile(profile)


def connect_remote(profile):
    proto = profile.get("protocol", "ftps")
    host, port = profile["host"], int(profile.get("port") or (22 if proto == "sftp" else 21))
    user, password = profile["username"], profile["password"]
    if proto == "sftp":
        try:
            import paramiko
        except ImportError:
            raise ApiError(400, "Modul SFTP belum tersedia. Jalankan: apt install python3-paramiko")
        ssh = paramiko.SSHClient()
        ssh.load_system_host_keys()
        ssh.set_missing_host_key_policy(paramiko.RejectPolicy())
        ssh.connect(hostname=host, port=port, username=user, password=password,
                    timeout=30, banner_timeout=30, auth_timeout=30,
                    look_for_keys=False, allow_agent=False)
        return ("sftp", ssh.open_sftp(), ssh)
    if proto == "ftps":
        ftp = ftplib.FTP_TLS(context=ssl.create_default_context(), timeout=30)
        ftp.connect(host, port, timeout=30)
        ftp.login(user, password)
        ftp.prot_p()
        return ("ftp", ftp, None)
    ftp = ftplib.FTP(timeout=30)
    ftp.connect(host, port, timeout=30)
    ftp.login(user, password)
    return ("ftp", ftp, None)


def remote_test(profile):
    kind, client, extra = connect_remote(profile)
    try:
        if kind == "sftp":
            client.listdir(profile.get("remote_dir") or ".")
        else:
            if profile.get("remote_dir"):
                client.cwd(profile["remote_dir"])
            client.pwd()
        return {"ok": True, "message": "Koneksi berhasil."}
    finally:
        try: client.close()
        except Exception: pass
        if extra:
            try: extra.close()
            except Exception: pass


def upload_remote_file(profile, rel):
    _rel, ap = abs_of(rel)
    if not os.path.isfile(ap):
        raise RuntimeError("File tidak ditemukan: " + rel)
    filename = os.path.basename(ap)
    kind, client, extra = connect_remote(profile)
    try:
        remote_dir = profile.get("remote_dir") or "."
        if kind == "sftp":
            try: client.chdir(remote_dir)
            except IOError: raise RuntimeError("Folder remote tidak ditemukan: " + remote_dir)
            client.put(ap, filename)
        else:
            if remote_dir:
                client.cwd(remote_dir)
            with open(ap, "rb") as fh:
                client.storbinary("STOR " + filename, fh, blocksize=1024 * 1024)
    finally:
        try: client.close()
        except Exception: pass
        if extra:
            try: extra.close()
            except Exception: pass


def remote_job_worker(job_id, profile, files):
    for rel in files:
        with REMOTE_JOBS_LOCK:
            REMOTE_JOBS[job_id]["current"] = os.path.basename(rel)
        try:
            upload_remote_file(profile, rel)
            store.mark_remote_upload(rel, profile["id"])
            result = {"path": rel, "ok": True, "message": "Berhasil"}
        except Exception as exc:
            result = {"path": rel, "ok": False, "message": str(exc)[:500]}
        with REMOTE_JOBS_LOCK:
            job = REMOTE_JOBS[job_id]
            job["results"].append(result)
            job["done"] = len(job["results"])
            job["success"] += 1 if result["ok"] else 0
            job["failed"] += 0 if result["ok"] else 1
    with REMOTE_JOBS_LOCK:
        REMOTE_JOBS[job_id]["status"] = "done"
        REMOTE_JOBS[job_id]["current"] = ""


def api_remote_profiles(q, b):
    if b.get("action") == "save":
        saved = save_remote_profile(b)
        return {"ok": True, "profile": saved, "profiles": [public_profile(x) for x in get_remote_profiles()]}
    if b.get("action") == "delete":
        pid = str(b.get("id", ""))
        store.put("remote_profiles", [x for x in get_remote_profiles() if x.get("id") != pid])
        return {"ok": True, "profiles": [public_profile(x) for x in get_remote_profiles()]}
    if b.get("action") == "test":
        pid = str(b.get("id", ""))
        profile = next((x for x in get_remote_profiles() if x.get("id") == pid), None)
        if not profile:
            profile = save_remote_profile(b)
        return remote_test(profile)
    return {"profiles": [public_profile(x) for x in get_remote_profiles()]}


def api_remote_start(q, b):
    pid = str(b.get("profile_id", ""))
    profile = next((x for x in get_remote_profiles() if x.get("id") == pid), None)
    if not profile:
        raise ApiError(404, "Profil tujuan tidak ditemukan.")
    files = b.get("files") or []
    if not isinstance(files, list) or not files or len(files) > 500:
        raise ApiError(400, "Pilih 1 sampai 500 file.")
    checked = []
    for rel in files:
        rel, ap = abs_of(str(rel))
        if not os.path.isfile(ap):
            raise ApiError(404, "File tidak ditemukan: " + rel)
        checked.append(rel)
    jid = uuid.uuid4().hex
    job = {"id": jid, "status": "running", "total": len(checked), "done": 0,
           "success": 0, "failed": 0, "current": "", "results": []}
    with REMOTE_JOBS_LOCK:
        REMOTE_JOBS[jid] = job
    threading.Thread(target=remote_job_worker, args=(jid, profile, checked), daemon=True).start()
    return {"ok": True, "job_id": jid}


def api_remote_status(q, b):
    jid = q.get("id", [""])[0]
    if not jid:
        return {"profiles": [public_profile(x) for x in get_remote_profiles()]}
    with REMOTE_JOBS_LOCK:
        job = REMOTE_JOBS.get(jid)
        if not job:
            raise ApiError(404, "Tugas upload tidak ditemukan.")
        return dict(job)

GET_ROUTES = {
    "/api/config": api_config,
    "/api/list": api_list,
    "/api/storage": api_storage,
    "/api/reclaimable": api_reclaimable,
    "/api/info": api_info,
    "/api/remote-profiles": api_remote_status,
}
POST_ROUTES = {
    "/api/mark": api_mark,
    "/api/move": api_move,
    "/api/copy": api_copy,
    "/api/delete": api_delete,
    "/api/mkdir": api_mkdir,
    "/api/rename": api_rename,
    "/api/settings": api_settings,
    "/api/rescan": api_rescan,
    "/api/remote-profiles": api_remote_profiles,
    "/api/remote-upload": api_remote_start,
}


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "Stockroom/" + VERSION
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    # --- helpers
    def _send(self, status, body, ctype, extra=None):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, status=200):
        self._send(status, json.dumps(obj).encode("utf-8"), "application/json; charset=utf-8")

    def _auth_ok(self):
        pw = STATE["password"]
        if not pw:
            return True
        h = self.headers.get("Authorization", "")
        if h.startswith("Basic "):
            try:
                given = base64.b64decode(h[6:]).decode("utf-8", "replace").split(":", 1)[1]
                return hmac.compare_digest(given.encode(), pw.encode())
            except Exception:
                return False
        return False

    def _host_ok(self):
        if STATE["any_host"]:
            return True
        host = self.headers.get("Host", "").rsplit(":", 1)[0].strip("[]").lower()
        return host in ("localhost", "127.0.0.1", "::1")

    def _send_file(self, path, ctype=None, cache=False):
        try:
            size = os.path.getsize(path)
        except OSError:
            raise ApiError(404, "File tidak ditemukan.")
        ctype = ctype or mimetypes.guess_type(path)[0] or "application/octet-stream"
        start, end, status = 0, size - 1, 200
        rng = self.headers.get("Range")
        if rng and rng.startswith("bytes=") and size > 0:
            try:
                a, bb = rng[6:].split(",")[0].split("-", 1)
                if a == "":
                    start = max(0, size - int(bb))
                else:
                    start = int(a)
                    end = int(bb) if bb else size - 1
                end = min(end, size - 1)
                if start > end:
                    raise ValueError
                status = 206
            except ValueError:
                self.send_response(416)
                self.send_header("Content-Range", "bytes */%d" % size)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
        length = end - start + 1 if size else 0
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        if getattr(self, "_download_name", None):
            name = self._download_name
            fallback = re.sub(r'[^A-Za-z0-9._ -]', '_', name).strip() or "download"
            self.send_header("Content-Disposition", "attachment; filename=\"%s\"; filename*=UTF-8''%s" % (fallback.replace('\\', '_').replace('\"', '_'), quote(name)))
        self.send_header("Content-Length", str(length))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "private, max-age=86400" if cache else "no-store")
        if ctype.startswith("image/svg"):
            self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; img-src data:; sandbox")
        if status == 206:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        self.end_headers()
        with open(path, "rb") as f:
            f.seek(start)
            left = length
            while left > 0:
                chunk = f.read(min(1 << 16, left))
                if not chunk:
                    break
                self.wfile.write(chunk)
                left -= len(chunk)

    def _serve_thumb(self, q, preview):
        rel, ap = abs_of(q.get("path", [""])[0])
        if not os.path.isfile(ap):
            raise ApiError(404, "File tidak ditemukan.")
        ext = os.path.splitext(ap)[1].lower().lstrip(".")
        if preview:
            w = 1800
            if ext in ("svg", "gif"):
                return self._send_file(ap)
        else:
            try:
                w = max(64, min(1200, int(q.get("w", ["320"])[0])))
            except ValueError:
                w = 320
            if ext == "svg":
                return self._send_file(ap, cache=True)
        t = make_thumb(ap, w)
        if t:
            return self._send_file(str(t), "image/png" if str(t).endswith(".png") else "image/jpeg", cache=True)
        if ext in NATIVE_IMG:
            return self._send_file(ap, cache=True)
        raise ApiError(404, "Tidak ada pratinjau.")

    # --- dispatch
    def do_GET(self):
        self._dispatch("GET")

    def do_PUT(self):
        temp_path = None
        try:
            if not self._host_ok():
                raise ApiError(403, "Host tidak diizinkan.")
            if not self._auth_ok():
                self._send(401, b"Perlu password.", "text/plain; charset=utf-8",
                           {"WWW-Authenticate": 'Basic realm="Stockroom"'})
                return
            if self.headers.get("X-Requested-With") != "stockroom":
                raise ApiError(403, "Permintaan ditolak.")
            u = urlparse(self.path)
            if u.path != "/api/upload":
                raise ApiError(404, "Tidak ditemukan.")
            q = parse_qs(u.query)
            _rel, dest = abs_of(q.get("path", [""])[0])
            if not os.path.isdir(dest):
                raise ApiError(404, "Folder tujuan tidak ditemukan.")
            try:
                size = int(self.headers.get("Content-Length", ""))
            except ValueError:
                raise ApiError(411, "Ukuran file tidak diketahui.")
            if size <= 0:
                raise ApiError(400, "File kosong atau ukuran tidak valid.")
            if size > 100 * 1024 * 1024 * 1024:
                raise ApiError(413, "Ukuran file melebihi batas 100 GB.")
            name = unquote(self.headers.get("X-File-Name", "")).strip()
            name = valid_name(name)
            temp_path = os.path.join(dest, ".%s.uploading" % uuid.uuid4().hex)
            remaining = size
            with open(temp_path, "xb") as out:
                while remaining:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ApiError(400, "Upload terputus sebelum selesai.")
                    out.write(chunk)
                    remaining -= len(chunk)
                out.flush()
                os.fsync(out.fileno())
            final_name = unique_dest(dest, name)
            os.replace(temp_path, os.path.join(dest, final_name))
            temp_path = None
            scanner.start()
            self._json({"ok": True, "name": final_name, "size": size})
        except ApiError as e:
            if temp_path and os.path.exists(temp_path):
                os.remove(temp_path)
            try:
                self._json({"error": e.msg}, e.status)
            except OSError:
                pass
        except OSError as e:
            if temp_path and os.path.exists(temp_path):
                try: os.remove(temp_path)
                except OSError: pass
            try:
                self._json({"error": "Gagal menyimpan file: %s" % (e.strerror or e)}, 507)
            except OSError:
                pass
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            if temp_path and os.path.exists(temp_path):
                try: os.remove(temp_path)
                except OSError: pass


    def do_POST(self):
        self._dispatch("POST")

    def _dispatch(self, method):
        try:
            body = {}
            if method == "POST":
                n = int(self.headers.get("Content-Length") or 0)
                raw = self.rfile.read(n) if 0 < n <= 8_000_000 else b""
                try:
                    body = json.loads(raw.decode("utf-8")) if raw else {}
                except ValueError:
                    raise ApiError(400, "Permintaan tidak valid.")
            if not self._host_ok():
                raise ApiError(403, "Host tidak diizinkan.")
            if not self._auth_ok():
                self._send(401, b"Perlu password.", "text/plain; charset=utf-8",
                           {"WWW-Authenticate": 'Basic realm="Stockroom"'})
                return
            u = urlparse(self.path)
            q = parse_qs(u.query)
            if method == "POST":
                if self.headers.get("X-Requested-With") != "stockroom":
                    raise ApiError(403, "Permintaan ditolak.")
                fn = POST_ROUTES.get(u.path)
                if not fn:
                    raise ApiError(404, "Tidak ditemukan.")
                return self._json(fn(q, body))
            if u.path in ("/", "/index.html"):
                html = (HERE / "static" / "index.html").read_bytes()
                return self._send(200, html, "text/html; charset=utf-8")
            if u.path == "/api/thumb":
                return self._serve_thumb(q, False)
            if u.path == "/api/preview":
                return self._serve_thumb(q, True)
            if u.path == "/api/file":
                rel, ap = abs_of(q.get("path", [""])[0])
                if not os.path.isfile(ap):
                    raise ApiError(404, "File tidak ditemukan.")
                self._download_name = os.path.basename(ap) if q.get("download", [""])[0] == "1" else None
                return self._send_file(ap)
            fn = GET_ROUTES.get(u.path)
            if fn:
                return self._json(fn(q, {}))
            raise ApiError(404, "Tidak ditemukan.")
        except ApiError as e:
            try:
                self._json({"error": e.msg}, e.status)
            except OSError:
                pass
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass
        except Exception as e:  # pragma: no cover
            traceback.print_exc()
            try:
                self._json({"error": "Kesalahan server: %s" % e}, 500)
            except OSError:
                pass


def port_open(host, port):
    try:
        with socket.create_connection((host, port), 0.4):
            return True
    except OSError:
        return False


def main():
    ap = argparse.ArgumentParser(description="Stockroom - manajer file upload microstock")
    ap.add_argument("--root", help="folder utama yang dikelola (default: yang terakhir dipakai atau ~/Microstock)")
    ap.add_argument("--host", default="127.0.0.1", help="alamat bind (default 127.0.0.1, hanya lokal)")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--password", default=os.environ.get("STOCKROOM_PASSWORD"),
                    help="password (wajib kalau --host bukan lokal)")
    ap.add_argument("--open", action="store_true", help="buka browser otomatis")
    a = ap.parse_args()

    local = a.host in ("127.0.0.1", "localhost", "::1")
    if not local and not a.password:
        sys.exit("Akses jaringan butuh password: tambahkan --password KATASANDI")

    url = "http://%s:%d/" % ("127.0.0.1" if local else a.host, a.port)
    if a.open and port_open("127.0.0.1", a.port):
        print("Stockroom sudah berjalan di", url)
        webbrowser.open(url)
        return

    root = a.root or store.get("root") or str(Path.home() / "Microstock")
    root = os.path.realpath(os.path.expanduser(root))
    os.makedirs(root, exist_ok=True)
    store.put("root", root)
    STATE.update(root=root, password=a.password, any_host=not local)
    scanner.start()

    srv = ThreadingHTTPServer((a.host, a.port), Handler)
    srv.daemon_threads = True
    print("Stockroom %s" % VERSION)
    print("  Folder utama : %s" % root)
    print("  Buka di      : %s" % url)
    print("  Thumbnail    : %s, video: %s" % ("Pillow" if HAS_PIL else "tanpa Pillow (lambat)", "ffmpeg" if HAS_FFMPEG else "tanpa ffmpeg"))
    if a.open:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nBerhenti.")


if __name__ == "__main__":
    main()
