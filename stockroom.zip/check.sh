#!/usr/bin/env bash
set -euo pipefail
echo "== Stockroom service =="
systemctl status stockroom --no-pager || true
echo
echo "== Listening port =="
ss -lntp | grep ':8765' || true
echo
echo "== HTTP check =="
python3 - <<'PY'
import urllib.request
try:
    r = urllib.request.urlopen("http://127.0.0.1:8765/", timeout=3)
    print("OK: HTTP", r.status)
except Exception as e:
    print("FAILED:", e)
    raise SystemExit(1)
PY
